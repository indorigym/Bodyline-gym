export interface GymBusinessInfo {
  name: string;
  category: string;
  address: string;
  landmark: string;
  city: string;
  state: string;
  pincode: string;
  fullAddress: string;
  phone: string;
  phoneFormatted: string;
  whatsappNumber: string;
  googleRating: number;
  reviewCount: number;
  openingHours: string;
  mapEmbedUrl: string;
  googleMapsUrl: string;
  instagramUrl: string;
  facebookUrl: string;
}

export interface StatItem {
  id: string;
  value: number;
  suffix: string;
  label: string;
  description: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  description: string;
  longDescription: string;
  iconName: string;
  benefits: string[];
  image: string;
}

export interface FeatureItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  tag: string;
}

export interface MembershipPlan {
  id: string;
  name: string;
  duration: string;
  price: number;
  originalPrice: number;
  popular?: boolean;
  tagline: string;
  features: string[];
  savings: string;
}

export interface Trainer {
  id: string;
  name: string;
  role: string;
  experience: string;
  specialization: string[];
  bio: string;
  image: string;
  certifications: string[];
  instagram: string;
  facebook: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'workout' | 'cardio' | 'strength' | 'group' | 'equipment' | 'members';
  image: string;
  caption: string;
}

export interface Transformation {
  id: string;
  memberName: string;
  age: number;
  occupation: string;
  goal: string;
  duration: string;
  weightLost: string;
  muscleGained: string;
  beforeImage: string;
  afterImage: string;
  testimonial: string;
  trainerName: string;
}

export interface Review {
  id: string;
  authorName: string;
  authorImage?: string;
  rating: number;
  relativeTimeText: string;
  text: string;
  verified: boolean;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'Membership' | 'Trial' | 'Facilities' | 'Trainers';
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  summary: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
  image: string;
  tags: string[];
}

export interface BookingFormData {
  name: string;
  phone: string;
  email: string;
  fitnessGoal: string;
  preferredTime: string;
  message?: string;
}

export interface BMICalculationResult {
  bmi: number;
  category: 'Underweight' | 'Normal Weight' | 'Overweight' | 'Obese';
  categoryColor: string;
  idealWeightRange: string;
  advice: string;
  recommendedServices: string[];
}
