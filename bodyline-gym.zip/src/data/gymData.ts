import {
  GymBusinessInfo,
  StatItem,
  ServiceItem,
  FeatureItem,
  MembershipPlan,
  Trainer,
  GalleryItem,
  Transformation,
  Review,
  FAQItem,
  BlogPost,
} from '../types';

import heroBgImage from '../assets/images/bodyline_hero_bg_1784967669489.jpg';
import trainerMaleImage from '../assets/images/bodyline_trainer_male_1784967684029.jpg';
import trainerFemaleImage from '../assets/images/bodyline_trainer_female_1784967696628.jpg';

export const GYM_BUSINESS_INFO: GymBusinessInfo = {
  name: 'Bodyline Gym',
  category: 'Premium Fitness Center',
  address: 'Itawaria Bazaar, 85, Hukumchand Marg',
  landmark: 'Maharaja Tukoji Rao Holker Cloth Market',
  city: 'Indore',
  state: 'Madhya Pradesh',
  pincode: '452002',
  fullAddress:
    'Itawaria Bazaar, 85, Hukumchand Marg, Itawaria Bazaar, Maharaja Tukoji Rao Holker Cloth Market, Indore, Madhya Pradesh 452002',
  phone: '+919644562525',
  phoneFormatted: '+91 96445 62525',
  whatsappNumber: '919644562525',
  googleRating: 4.8,
  reviewCount: 534,
  openingHours: 'Open Daily – 6:00 AM to 11:00 PM',
  mapEmbedUrl:
    'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3680.123!2d75.8577!3d22.7196!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3962fcad8d77d123%3A0x123456789abcdef!2sHukumchand%20Marg%2C%20Itawaria%20Bazaar%2C%20Indore%2C%20Madhya%20Pradesh%20452002!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin',
  googleMapsUrl:
    'https://maps.google.com/?q=Bodyline+Gym+Itawaria+Bazaar+Hukumchand+Marg+Indore+Madhya+Pradesh+452002',
  instagramUrl: 'https://www.instagram.com/gym_bodyline?igsh=b2V6aW44aTlvZmE5',
  facebookUrl: 'https://www.facebook.com/bodylinegymindore/',
};

export const HERO_BG_IMAGE = heroBgImage;

export const GYM_STATS: StatItem[] = [
  {
    id: 'members',
    value: 2500,
    suffix: '+',
    label: 'Happy Members',
    description: 'Active fitness enthusiasts training with us in Indore',
  },
  {
    id: 'trainers',
    value: 12,
    suffix: '+',
    label: 'Expert Trainers',
    description: 'Certified powerlifters, bodybuilders & wellness coaches',
  },
  {
    id: 'years',
    value: 10,
    suffix: '+',
    label: 'Years of Excellence',
    description: 'Delivering unmatched fitness results in MP',
  },
  {
    id: 'transformations',
    value: 1200,
    suffix: '+',
    label: 'Transformations',
    description: 'Life-changing weight loss and muscle building journeys',
  },
];

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'weight-training',
    title: 'Weight Training',
    category: 'Strength & Hypertrophy',
    description: 'State-of-the-art free weights, squat racks, leg presses, and heavy plates to sculpt strength.',
    longDescription:
      'Engineered for maximum muscle building and raw strength gains. Our strength zone features imported Olympic plates, heavy-duty dumbbells up to 50kg, power cages, cable crossovers, and specialized biomechanical machines.',
    iconName: 'Dumbbell',
    benefits: ['Hypertrophy & Muscle Mass', 'Increased Bone Density', 'Postural Alignment', 'Strength Progression'],
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'personal-training',
    title: 'Personal Training',
    category: '1-on-1 Coaching',
    description: 'Dedicated 1-on-1 guidance with personalized workout routines, form correction, and diet plans.',
    longDescription:
      'Accelerate your results with a dedicated certified coach who customizes every rep, sets macro-based nutrition targets, and provides relentless accountability tailored to your body type.',
    iconName: 'UserCheck',
    benefits: ['Faster Results', 'Zero Injury Risk Form', 'Customized Diet Plan', 'Daily Accountability'],
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'hiit-classes',
    title: 'HIIT Classes',
    category: 'Fat Loss & Endurance',
    description: 'High-Intensity Interval Training designed to burn maximum calories in minimum time.',
    longDescription:
      'Boost your metabolic rate for up to 24 hours post-workout. High-energy group HIIT sessions utilizing kettlebells, battle ropes, plyo boxes, and bodyweight intervals.',
    iconName: 'Zap',
    benefits: ['Maximum Calorie Afterburn', 'Cardiovascular Stamina', 'Rapid Fat Loss', 'High Energy Group Vibe'],
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'crossfit',
    title: 'CrossFit',
    category: 'Functional Fitness',
    description: 'Functional high-potency workouts blending Olympic lifts, gymnastics, and metabolic conditioning.',
    longDescription:
      'Build functional agility, power, and core endurance. Our CrossFit box area includes gymnastics rings, sled pushes, bumper plates, and climbing ropes.',
    iconName: 'Flame',
    benefits: ['Explosive Athletic Power', 'Core Stability', 'Agility & Speed', 'Community Spirit'],
    image: 'https://images.unsplash.com/photo-1534367507873-d2d7e24c797f?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'zumba',
    title: 'Zumba',
    category: 'Dance & Cardio',
    description: 'Fun, high-energy Latin and Bollywood dance workouts led by certified Zumba instructors.',
    longDescription:
      'Dance your way to fitness with uplifting music tracks, high calorie burn, and an infectious group energy that makes cardio feel like a party.',
    iconName: 'Music',
    benefits: ['Stress Release', 'Full Body Toning', 'Burns 600+ Calories/Hr', 'Great Rhythm & Fun'],
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'aerobics',
    title: 'Aerobics',
    category: 'Rhythmic Conditioning',
    description: 'Structured rhythmic aerobic exercise sessions for heart health, flexibility, and stamina.',
    longDescription:
      'Improve lung capacity, circulatory health, and joint mobility in our spacious wooden-floored studio with dynamic audio-visual equipment.',
    iconName: 'Activity',
    benefits: ['Cardiovascular Strength', 'Improved Endurance', 'Enhanced Flexibility', 'Weight Management'],
    image: 'https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'kickboxing',
    title: 'Kickboxing',
    category: 'Combat & Core',
    description: 'Full-body martial arts conditioning involving striking heavy bags, pad work, and self-defense.',
    longDescription:
      'Master punch and kick combinations while developing intense core strength, hand-eye coordination, and stress relief on heavy leather punching bags.',
    iconName: 'ShieldAlert',
    benefits: ['Self Defense Skills', 'Core & Leg Conditioning', 'Stress Relief', 'Explosive Stamina'],
    image: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'cycling',
    title: 'Spinning / Cycling',
    category: 'Legs & Cardio',
    description: 'High-intensity indoor stationary bike spinning sessions with motivating beats and hill climbs.',
    longDescription:
      'Low-impact, high-reward cardiovascular workout on premium magnetic spin bikes with adjustable resistance, speed tracking, and heart-pounding beats.',
    iconName: 'Bike',
    benefits: ['Zero Knee Strain', 'Quad & Glute Sculpting', 'High Endurance', 'Calorie Burning'],
    image: 'https://images.unsplash.com/photo-1534258936925-c58bed479fcb?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'dance-fitness',
    title: 'Dance Fitness',
    category: 'Group Rhythm',
    description: 'Freestyle Bollywood and hip-hop dance routines designed to keep your heart pumping.',
    longDescription:
      'Combine rhythm, flexibility, and high-tempo choreography in an inclusive studio environment that boosts mood and calorie expenditure.',
    iconName: 'HeartHandshake',
    benefits: ['Mood Booster', 'Agility', 'Coordination', 'Group Bonding'],
    image: 'https://images.unsplash.com/photo-1524594152303-9fd13543fe6e?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'private-training',
    title: 'Private VIP Training',
    category: 'Elite Coaching',
    description: 'Exclusive private training slots with senior coaches, custom biomechanical assessments & privacy.',
    longDescription:
      'Designed for business executives, athletes, and individuals seeking maximum privacy and hyper-tailored training protocols.',
    iconName: 'Award',
    benefits: ['Exclusive Studio Access', 'Senior Master Coach', 'Comprehensive Health Screening', 'Flexibility'],
    image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?auto=format&fit=crop&w=800&q=80',
  },
];

export const FEATURES_DATA: FeatureItem[] = [
  {
    id: 'certified-trainers',
    title: 'Certified Trainers',
    description: 'ACE, K11, and ISSA certified male and female fitness professionals dedicated to your goals.',
    iconName: 'Award',
    tag: 'Expertise',
  },
  {
    id: 'latest-equipment',
    title: 'Latest Equipment',
    description: 'Imported heavy-duty gym machinery, biomechanically aligned squat racks, cables, and cardio rigs.',
    iconName: 'Dumbbell',
    tag: 'Infrastructure',
  },
  {
    id: 'affordable-membership',
    title: 'Affordable Membership',
    description: 'Best-in-value pricing packages in Indore with flexible monthly, quarterly, and annual options.',
    iconName: 'Tag',
    tag: 'Best Value',
  },
  {
    id: 'hygiene-safety',
    title: 'Hygiene & Safety',
    description: 'Sanitized equipment, air-purified workout environment, clean changing rooms, and lockers.',
    iconName: 'Sparkles',
    tag: '100% Clean',
  },
  {
    id: 'flexible-timings',
    title: 'Flexible Timings',
    description: 'Open 7 days a week from 6:00 AM to 11:00 PM so you never miss a workout slot.',
    iconName: 'Clock',
    tag: 'Convenience',
  },
  {
    id: 'personalized-workout',
    title: 'Personalized Workout Plans',
    description: 'Customized training cards and app tracking based on your specific body metrics and goals.',
    iconName: 'FileText',
    tag: 'Tailored',
  },
  {
    id: 'nutrition-guidance',
    title: 'Nutrition Guidance',
    description: 'Practical vegetarian and non-vegetarian macro meal plans suitable for Indian dietary habits.',
    iconName: 'Apple',
    tag: 'Diet Support',
  },
  {
    id: 'friendly-community',
    title: 'Friendly Community',
    description: 'Welcoming, supportive atmosphere for beginners, female fitness seekers, and seasoned athletes.',
    iconName: 'Users',
    tag: 'Atmosphere',
  },
];

export const MEMBERSHIP_PLANS: MembershipPlan[] = [
  {
    id: 'monthly',
    name: 'Monthly Plan',
    duration: '1 Month',
    price: 1500,
    originalPrice: 2000,
    tagline: 'Ideal for trying out our facilities with complete flexibility.',
    savings: 'Save ₹500',
    features: [
      'Full Gym Floor Access',
      'Cardio & Strength Zones',
      'Locker & Changing Rooms',
      'General Fitness Assessment',
      'Open 6 AM - 11 PM',
    ],
  },
  {
    id: 'quarterly',
    name: 'Quarterly Plan',
    duration: '3 Months',
    price: 4000,
    originalPrice: 5500,
    tagline: 'Great balance of commitment and savings for consistent training.',
    savings: 'Save ₹1,500',
    features: [
      'Everything in Monthly Plan',
      '1 Free Personal Training Session',
      'Basic Nutrition Chart',
      'Group Class Access (Zumba/HIIT)',
      'Free Locker Facility',
    ],
  },
  {
    id: 'annual',
    name: 'Annual Plan',
    duration: '12 Months',
    price: 11999,
    originalPrice: 18000,
    popular: true,
    tagline: 'Our best value membership for complete physical transformation.',
    savings: 'Save ₹6,001 (Most Popular)',
    features: [
      'Unlimited Gym & Cardio Access',
      '3 Free Personal Training Sessions',
      'Full Custom Macro Diet Plan',
      'Unlimited Zumba & HIIT Classes',
      'Monthly InBody Body Fat Analysis',
      'Free Gym Kit Bag & Shaker',
      'Freeze Membership (Up to 30 Days)',
    ],
  },
  {
    id: 'half-yearly',
    name: 'Half-Yearly Plan',
    duration: '6 Months',
    price: 7000,
    originalPrice: 10000,
    tagline: 'Serious 6-month transformation roadmap for dedicated fitness goals.',
    savings: 'Save ₹3,000',
    features: [
      'Everything in Quarterly Plan',
      '2 Free Personal Training Sessions',
      'Detailed Diet & Supplement Guide',
      'Monthly BMI & Body Measurement',
      'Priority Locker Access',
    ],
  },
];

export const TRAINERS_DATA: Trainer[] = [
  {
    id: 'trainer-vikram',
    name: 'Vikram Sharma',
    role: 'Head Strength & Conditioning Coach',
    experience: '9+ Years Experience',
    specialization: ['Heavy Powerlifting', 'Bodybuilding', 'Muscle Mass Building', 'Postural Correction'],
    bio: 'Former State Powerlifting champion with over 9 years of hands-on experience transforming over 600+ clients in Indore.',
    image: trainerMaleImage,
    certifications: ['K11 Master Trainer Certified', 'NSCA Certified Strength Specialist'],
    instagram: 'https://www.instagram.com/gym_bodyline?igsh=b2V6aW44aTlvZmE5',
    facebook: 'https://www.facebook.com/bodylinegymindore/',
  },
  {
    id: 'trainer-neha',
    name: 'Neha Patel',
    role: 'CrossFit & Women Fitness Specialist',
    experience: '6+ Years Experience',
    specialization: ['CrossFit Training', 'Post-Pregnancy Fitness', 'Weight Loss', 'Zumba Dance'],
    bio: 'Passionate fitness athlete specializing in functional fat loss, high energy group workouts, and women-focused strength training.',
    image: trainerFemaleImage,
    certifications: ['ACE Certified Personal Trainer', 'ZIN Licensed Zumba Instructor'],
    instagram: 'https://www.instagram.com/gym_bodyline?igsh=b2V6aW44aTlvZmE5',
    facebook: 'https://www.facebook.com/bodylinegymindore/',
  },
  {
    id: 'trainer-rajesh',
    name: 'Rajesh Verma',
    role: 'Transformation & HIIT Specialist',
    experience: '7+ Years Experience',
    specialization: ['Fat Loss', 'HIIT & Endurance', 'Bodyweight Calisthenics', 'Nutrition Planning'],
    bio: 'Known for high-intensity motivation and meticulous macro meal prep advice that yields visible results within 8-12 weeks.',
    image: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?auto=format&fit=crop&w=800&q=80',
    certifications: ['ISSA Certified Fitness Trainer', 'Precision Nutrition Level 1'],
    instagram: 'https://www.instagram.com/gym_bodyline?igsh=b2V6aW44aTlvZmE5',
    facebook: 'https://www.facebook.com/bodylinegymindore/',
  },
  {
    id: 'trainer-ananya',
    name: 'Ananya Holkar',
    role: 'Nutritionist & Aerobics Coach',
    experience: '5+ Years Experience',
    specialization: ['Vegetarian Indian Diets', 'Aerobics & Flexibility', 'Core Toning', 'Lifestyle Coaching'],
    bio: 'Specializes in practical Indore-friendly vegetarian meal charts and fun cardiovascular dance workouts.',
    image: 'https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&w=800&q=80',
    certifications: ['Diploma in Clinical Nutrition', 'Certified Aerobics Instructor'],
    instagram: 'https://www.instagram.com/gym_bodyline?igsh=b2V6aW44aTlvZmE5',
    facebook: 'https://www.facebook.com/bodylinegymindore/',
  },
];

export const GALLERY_DATA: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Heavy Strength & Free Weights Arena',
    category: 'strength',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1000&q=80',
    caption: 'Olympic squat racks, heavy dumbell racks, and deadlift platforms at Bodyline Gym Indore.',
  },
  {
    id: 'g2',
    title: 'Cardio Deck & Treadmill Lineup',
    category: 'cardio',
    image: 'https://images.unsplash.com/photo-1576678927484-cc909957088c?auto=format&fit=crop&w=1000&q=80',
    caption: 'Premium interactive treadmills, ellipticals, and spin bikes with individual display telemetry.',
  },
  {
    id: 'g3',
    title: 'Functional CrossFit & Battle Ropes Box',
    category: 'workout',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1000&q=80',
    caption: 'High-octane functional training space with battle ropes, plyo boxes, and kettlebells.',
  },
  {
    id: 'g4',
    title: 'Group Aerobics & Zumba Studio',
    category: 'group',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1000&q=80',
    caption: 'Spacious mirrored studio equipped with surround sound for Zumba, HIIT, and Yoga classes.',
  },
  {
    id: 'g5',
    title: 'Imported Biomechanical Machinery',
    category: 'equipment',
    image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=1000&q=80',
    caption: 'Precision cable machines, leg press, lat pulldown, and chest press machines.',
  },
  {
    id: 'g6',
    title: 'Dedicated Members Workout Area',
    category: 'members',
    image: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?auto=format&fit=crop&w=1000&q=80',
    caption: 'Motivating atmosphere with clean environment, red ambient lighting, and friendly gym vibes.',
  },
  {
    id: 'g7',
    title: 'Personal Training Guidance Session',
    category: 'members',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=1000&q=80',
    caption: '1-on-1 form correction and motivation with our certified master trainers.',
  },
  {
    id: 'g8',
    title: 'Heavy Cable Cross & Lat Pull Zone',
    category: 'strength',
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=1000&q=80',
    caption: 'Versatile multi-station cable crossover for chest, arms, back, and shoulders.',
  },
];

export const TRANSFORMATIONS_DATA: Transformation[] = [
  {
    id: 't1',
    memberName: 'Rahul Aggarwal',
    age: 28,
    occupation: 'IT Professional (Indore)',
    goal: 'Fat Loss & Muscle Toning',
    duration: '4 Months',
    weightLost: '18 kg Lost',
    muscleGained: '3.5 kg Lean Muscle',
    beforeImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    afterImage: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=600&q=80',
    testimonial:
      'I was struggling with high belly fat and desk job sluggishness. Joining Bodyline Gym at Itawaria Bazaar changed my life! Coach Vikram guided my workout routines and diet chart. Down 18kg and feeling more energetic than ever!',
    trainerName: 'Vikram Sharma',
  },
  {
    id: 't2',
    memberName: 'Pooja Jain',
    age: 32,
    occupation: 'Entrepreneur',
    goal: 'Post-Pregnancy Weight Loss & Core Strength',
    duration: '5 Months',
    weightLost: '14 kg Lost',
    muscleGained: 'Core Toned',
    beforeImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    afterImage: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80',
    testimonial:
      'The women-friendly environment and certified guidance from Neha Ma’am gave me complete confidence. The combination of Zumba and strength training helped me shed 14 kg safely.',
    trainerName: 'Neha Patel',
  },
  {
    id: 't3',
    memberName: 'Aman Holkar',
    age: 23,
    occupation: 'College Student',
    goal: 'Lean Muscle Hypertrophy',
    duration: '6 Months',
    weightLost: 'Bulking Phase',
    muscleGained: '11 kg Lean Mass',
    beforeImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80',
    afterImage: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?auto=format&fit=crop&w=600&q=80',
    testimonial:
      'I used to be extremely skinny. The heavy equipment, progressive overload guidance, and protein diet support at Bodyline Gym helped me gain 11kg of solid lean muscle!',
    trainerName: 'Rajesh Verma',
  },
];

export const GOOGLE_REVIEWS_DATA: Review[] = [
  {
    id: 'r1',
    authorName: 'Shubham Joshi',
    rating: 5,
    relativeTimeText: '2 weeks ago',
    text: 'Best gym in Itawaria Bazaar, Indore! Clean atmosphere, top-notch equipment, and very polite trainers. Coach Vikram gives personal attention even during peak hours.',
    verified: true,
  },
  {
    id: 'r2',
    authorName: 'Priyanka Sharma',
    rating: 5,
    relativeTimeText: '1 month ago',
    text: 'Bodyline Gym is super comfortable for female members. The Zumba and CrossFit sessions with Neha maam are high energy and fun! Highly recommended in Hukumchand Marg area.',
    verified: true,
  },
  {
    id: 'r3',
    authorName: 'Deepak Patidar',
    rating: 5,
    relativeTimeText: '3 weeks ago',
    text: 'Solid 4.8 star rating well deserved! Affordable membership fees with premium machinery. Open till 11 PM which fits my business working hours perfectly.',
    verified: true,
  },
  {
    id: 'r4',
    authorName: 'Gaurav Khandelwal',
    rating: 5,
    relativeTimeText: '2 months ago',
    text: 'Transformed my body in 3 months! The trainers actually guide you on proper form and nutrition. Great community spirit.',
    verified: true,
  },
  {
    id: 'r5',
    authorName: 'Kavita Malviya',
    rating: 5,
    relativeTimeText: 'a month ago',
    text: 'Clean changing rooms, great air conditioning, and helpful trainers. The free trial experience was so smooth I joined the annual plan on the spot!',
    verified: true,
  },
];

export const FAQ_DATA: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'What are the gym operating hours at Bodyline Gym?',
    answer:
      'We are open daily from 6:00 AM to 11:00 PM, 7 days a week including Sundays, giving you maximum flexibility to workout whenever suits your schedule.',
    category: 'Facilities',
  },
  {
    id: 'faq-2',
    question: 'Where is Bodyline Gym located in Indore?',
    answer:
      'We are located at Itawaria Bazaar, 85, Hukumchand Marg, near Maharaja Tukoji Rao Holker Cloth Market, Indore, Madhya Pradesh 452002.',
    category: 'Facilities',
  },
  {
    id: 'faq-3',
    question: 'Can I get a free trial pass before taking a membership?',
    answer:
      'Yes! We offer a complimentary 1-Day Free Trial pass so you can experience our equipment, workout vibe, and meet our trainers. Simply fill out our Free Trial booking form or WhatsApp us at +91 96445 62525.',
    category: 'Trial',
  },
  {
    id: 'faq-4',
    question: 'Do you offer personal training (PT)?',
    answer:
      'Yes, we have certified male and female personal trainers who provide 1-on-1 coaching, customized workout regimens, body fat monitoring, and tailored diet charts.',
    category: 'Trainers',
  },
  {
    id: 'faq-5',
    question: 'What membership plans are available and what are the fees?',
    answer:
      'We offer flexible plans: Monthly (₹1,500), Quarterly (₹4,000), Half-Yearly (₹7,000), and Annual (₹11,999 - Most Popular). All memberships include full gym floor and cardio access.',
    category: 'Membership',
  },
  {
    id: 'faq-6',
    question: 'Are group classes like Zumba and HIIT included in membership?',
    answer:
      'Yes! Quarterly, Half-Yearly, and Annual membership plans include access to our group cardio, Zumba, and HIIT sessions.',
    category: 'Membership',
  },
  {
    id: 'faq-7',
    question: 'Is parking and locker facility available?',
    answer:
      'Yes, we provide safe vehicle parking area for two-wheelers and four-wheelers at Itawaria Bazaar, as well as secure lockers and clean changing rooms.',
    category: 'Facilities',
  },
  {
    id: 'faq-8',
    question: 'Is Bodyline Gym beginner and female-friendly?',
    answer:
      'Absolutely! We take pride in maintaining a respectable, safe, clean, and highly supportive environment for female members, beginners, and fitness enthusiasts of all ages.',
    category: 'Facilities',
  },
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'b1',
    title: 'Top 5 Gym Habits to Burn Belly Fat Fast in Indore',
    slug: 'top-5-gym-habits-burn-belly-fat',
    summary: 'Discover proven strength and cardio techniques combined with local diet tweaks to shed belly fat consistently.',
    content: `
Belly fat can be persistent, but with the right gym protocol and nutrition discipline, you can achieve remarkable results. Here are 5 habits recommended by Coach Vikram at Bodyline Gym Indore:

1. Prioritize Progressive Compound Lifting (Squats, Deadlifts, Presses)
2. Incorporate 15-Minute Post-Workout HIIT Intervals
3. Track Your Daily Protein Intake (Aim for 1.6g to 2g per kg body weight)
4. Hydrate Adequately (3-4 Liters of clean water daily)
5. Ensure 7 to 8 Hours of Sleep for Hormone Balance and Muscle Recovery.
    `,
    author: 'Vikram Sharma (Head Strength Coach)',
    date: 'July 18, 2026',
    readTime: '4 min read',
    category: 'Workout Tips',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80',
    tags: ['Fat Loss', 'Gym Routine', 'Indore Fitness'],
  },
  {
    id: 'b2',
    title: 'High Protein Vegetarian Diet Guide for Indian Fitness Lovers',
    slug: 'high-protein-vegetarian-diet-guide',
    summary: 'How to meet your daily muscle-building protein targets with affordable Indian vegetarian foods like paneer, soya, and dal.',
    content: `
Many gym-goers in Indore assume vegetarian diets lack protein. That is a myth! Here is how you can hit 100g+ protein on a vegetarian diet:

- Paneer (Cottage Cheese) - 18g protein per 100g
- Soya Chunks - 52g protein per 100g (dry)
- Greek Yogurt / Hung Curd - 10g protein per bowl
- Moong Dal & Chana - Excellent complex carbs + fiber
- Whey Protein Supplement (Optional post-workout scoop).
    `,
    author: 'Ananya Holkar (Nutritionist)',
    date: 'July 10, 2026',
    readTime: '5 min read',
    category: 'Nutrition',
    image: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800&q=80',
    tags: ['Vegetarian Diet', 'Protein', 'Indore Health'],
  },
  {
    id: 'b3',
    title: 'Why Consistency Trumps Intensity: 3 Month Fitness Roadmap',
    slug: 'consistency-trumps-intensity-fitness-roadmap',
    summary: 'Learn why showing up 4-5 days a week consistently outperforms extreme short-lived workouts.',
    content: `
A common mistake beginners make at Bodyline Gym is going 100% hard in week one and dropping out in week two due to intense soreness. 

Building a lasting physique requires 80% consistency month after month. Focus on showing up 4 days a week, mastering your exercise form, sleeping well, and trusting the process!
    `,
    author: 'Neha Patel (CrossFit Coach)',
    date: 'June 28, 2026',
    readTime: '3 min read',
    category: 'Motivation',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=800&q=80',
    tags: ['Motivation', 'Beginner Guide', 'Gym Habits'],
  },
];
