import { useState, useEffect } from 'react';
import { MessageSquare, ArrowUp, Calendar, Phone } from 'lucide-react';
import { GYM_BUSINESS_INFO } from '../data/gymData';

interface FloatingControlsProps {
  onOpenFreeTrialModal: () => void;
}

export default function FloatingControls({
  onOpenFreeTrialModal,
}: FloatingControlsProps) {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Floating WhatsApp Button */}
      <a
        href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=Hi%20Bodyline%20Gym!%20I%20would%20like%20to%20inquire%20about%20gym%20membership%20and%20free%20trial.`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-emerald-500 text-white shadow-2xl flex items-center justify-center hover:bg-emerald-600 transition-all transform hover:scale-110 active:scale-95 group"
        title="Chat on WhatsApp (+91 96445 62525)"
        aria-label="WhatsApp Bodyline Gym"
      >
        <span className="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-30 pointer-events-none"></span>
        <MessageSquare className="w-7 h-7 fill-white text-emerald-500" />
      </a>

      {/* Floating Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-24 right-6 z-40 w-11 h-11 bg-zinc-900 text-white border border-white/20 shadow-xl flex items-center justify-center hover:bg-[#FF2D2D] hover:border-[#FF2D2D] transition-all transform hover:scale-105"
          title="Scroll to Top"
          aria-label="Scroll to Top"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

      {/* Sticky Mobile Bottom Bar */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-30 bg-black border-t border-white/10 p-3 flex items-center gap-2 shadow-2xl">
        <a
          href={`tel:${GYM_BUSINESS_INFO.phone}`}
          className="flex-1 py-3 bg-zinc-900 text-white text-xs font-black uppercase tracking-wider text-center flex items-center justify-center gap-1.5 border border-white/10"
        >
          <Phone className="w-3.5 h-3.5 text-[#FF2D2D]" />
          <span>Call Desk</span>
        </a>

        <button
          onClick={onOpenFreeTrialModal}
          className="flex-1 py-3 bg-[#FF2D2D] text-white text-xs font-black uppercase tracking-wider text-center flex items-center justify-center gap-1.5 shadow-lg"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Book Free Pass</span>
        </button>
      </div>
    </>
  );
}
