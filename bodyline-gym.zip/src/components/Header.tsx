import { useState, useEffect } from 'react';
import { Dumbbell, Phone, MessageSquare, Menu, X, Star, Calendar, Instagram, Facebook } from 'lucide-react';
import { GYM_BUSINESS_INFO } from '../data/gymData';

interface HeaderProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenFreeTrialModal: () => void;
}

export default function Header({
  activeSection,
  onNavigate,
  onOpenFreeTrialModal,
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'hero', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'services', label: 'Services' },
    { id: 'memberships', label: 'Plans' },
    { id: 'trainers', label: 'Trainers' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'transformations', label: 'Results' },
    { id: 'bmi', label: 'BMI Tool' },
    { id: 'reviews', label: 'Reviews' },
    { id: 'blog', label: 'Blog' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0B0B0B]/90 backdrop-blur-md border-b border-[#1E1E1E] shadow-2xl py-3'
          : 'bg-gradient-to-b from-black/90 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('hero')}
            className="flex items-center gap-2.5 group text-left focus:outline-none"
            aria-label="Bodyline Gym Home"
          >
            <div className="w-8 h-8 bg-[#FF2D2D] text-black font-black italic flex items-center justify-center text-lg group-hover:bg-white group-hover:text-black transition-colors">
              B
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="text-xl sm:text-2xl font-black tracking-tighter text-white uppercase font-heading">
                  BODYLINE<span className="text-[#FF2D2D]">GYM</span>
                </span>
              </div>
              <p className="text-[9px] text-zinc-400 font-bold tracking-[0.2em] uppercase -mt-1 flex items-center gap-1.5">
                <span>INDORE</span>
                <span className="inline-block w-1 h-1 bg-[#FF2D2D]"></span>
                <span className="text-yellow-400 flex items-center gap-0.5">
                  <Star className="w-2.5 h-2.5 fill-yellow-400 text-yellow-400" />
                  4.8★
                </span>
              </p>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 bg-zinc-900/80 border border-white/10 px-5 py-2 backdrop-blur-md">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-1 text-xs font-black uppercase tracking-widest transition-all duration-200 ${
                    isActive
                      ? 'text-[#FF2D2D] border-b-2 border-[#FF2D2D]'
                      : 'text-zinc-300 hover:text-[#FF2D2D]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Header Action Buttons */}
          <div className="hidden sm:flex items-center gap-2">
            <a
              href={GYM_BUSINESS_INFO.instagramUrl}
              target="_blank"
              rel="noreferrer noopener"
              referrerPolicy="no-referrer"
              className="p-2.5 bg-zinc-900 text-zinc-300 hover:text-white hover:bg-[#E1306C] transition-colors border border-white/10"
              title="Instagram"
              aria-label="Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>
            <a
              href={GYM_BUSINESS_INFO.facebookUrl}
              target="_blank"
              rel="noreferrer noopener"
              referrerPolicy="no-referrer"
              className="p-2.5 bg-zinc-900 text-zinc-300 hover:text-white hover:bg-[#1877F2] transition-colors border border-white/10"
              title="Facebook"
              aria-label="Facebook"
            >
              <Facebook className="w-4 h-4" />
            </a>
            <a
              href={`tel:${GYM_BUSINESS_INFO.phone}`}
              className="p-2.5 bg-zinc-900 text-zinc-300 hover:text-white hover:bg-[#FF2D2D] transition-colors border border-white/10"
              title="Call Bodyline Gym"
              aria-label="Call Bodyline Gym"
            >
              <Phone className="w-4 h-4" />
            </a>
            <a
              href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=Hi%20Bodyline%20Gym%2C%20I%20want%20to%20inquire%20about%20membership%20and%20free%20trial.`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 bg-zinc-900 text-emerald-400 hover:bg-emerald-600 hover:text-white transition-colors border border-white/10"
              title="Chat on WhatsApp"
              aria-label="Chat on WhatsApp"
            >
              <MessageSquare className="w-4 h-4" />
            </a>
            <button
              onClick={onOpenFreeTrialModal}
              className="bg-[#FF2D2D] text-white px-5 py-2.5 text-xs font-black uppercase tracking-widest hover:bg-white hover:text-black transition-colors flex items-center gap-2 shadow-[0_0_15px_rgba(255,45,45,0.3)]"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Join Now</span>
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={onOpenFreeTrialModal}
              className="sm:hidden px-3 py-1.5 rounded-full bg-[#FF2D2D] text-white text-[11px] font-bold uppercase tracking-wider"
            >
              Free Trial
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-[#1E1E1E] text-white border border-white/10 focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5 text-[#FF2D2D]" />
              ) : (
                <Menu className="w-5 h-5 text-gray-200" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-[65px] bg-[#0B0B0B]/98 border-b border-[#1E1E1E] backdrop-blur-xl p-5 shadow-2xl transition-all">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-2.5 text-xs font-medium rounded-xl text-left transition-all ${
                  activeSection === item.id
                    ? 'bg-[#FF2D2D] text-white font-bold'
                    : 'bg-[#1E1E1E]/80 text-gray-300 hover:bg-[#1E1E1E] hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-[#1E1E1E] flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenFreeTrialModal();
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF2D2D] to-[#b30000] text-white font-bold text-xs uppercase tracking-wider text-center shadow-lg shadow-[#FF2D2D]/30"
            >
              Book Free Trial Session
            </button>
            <div className="grid grid-cols-2 gap-2">
              <a
                href={GYM_BUSINESS_INFO.instagramUrl}
                target="_blank"
                rel="noreferrer noopener"
                referrerPolicy="no-referrer"
                className="py-2.5 bg-[#E1306C] text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <Instagram className="w-4 h-4" />
                <span>Instagram</span>
              </a>
              <a
                href={GYM_BUSINESS_INFO.facebookUrl}
                target="_blank"
                rel="noreferrer noopener"
                referrerPolicy="no-referrer"
                className="py-2.5 bg-[#1877F2] text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <Facebook className="w-4 h-4" />
                <span>Facebook</span>
              </a>
              <a
                href={`tel:${GYM_BUSINESS_INFO.phone}`}
                className="py-2.5 bg-zinc-900 text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 border border-white/10"
              >
                <Phone className="w-3.5 h-3.5 text-[#FF2D2D]" />
                <span>Call Now</span>
              </a>
              <a
                href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=Hi%20Bodyline%20Gym%2C%20I%20want%20to%20inquire%20about%20memberships.`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 bg-emerald-600 text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
