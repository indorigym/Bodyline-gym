import { useState } from 'react';
import {
  Check,
  Zap,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Tag,
  Gift,
} from 'lucide-react';
import { MEMBERSHIP_PLANS } from '../data/gymData';
import { MembershipPlan } from '../types';

interface MembershipPlansProps {
  onSelectPlan: (plan: MembershipPlan) => void;
  onOpenFreeTrialModal: () => void;
}

export default function MembershipPlans({
  onSelectPlan,
  onOpenFreeTrialModal,
}: MembershipPlansProps) {
  const [billingCycle, setBillingCycle] = useState<'all' | 'popular'>('all');

  return (
    <section id="memberships" className="py-20 bg-[#0E0E0E] relative border-t border-[#1E1E1E]">
      {/* Background Accent Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#FF2D2D]/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Affordable Excellence
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Membership <span className="text-[#FF2D2D] text-stroke-white">Plans & Pricing</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            Choose the membership tier that fits your fitness ambition. No hidden costs, full access to equipment, and supportive guidance included.
          </p>

          {/* Quick Filter Toggle */}
          <div className="inline-flex items-center bg-zinc-900 p-1.5 border border-white/10 mt-6">
            <button
              onClick={() => setBillingCycle('all')}
              className={`px-5 py-2 text-xs font-black uppercase tracking-widest transition-all ${
                billingCycle === 'all'
                  ? 'bg-[#FF2D2D] text-white shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              All Plans
            </button>
            <button
              onClick={() => setBillingCycle('popular')}
              className={`px-5 py-2 text-xs font-black uppercase tracking-widest transition-all flex items-center gap-1.5 ${
                billingCycle === 'popular'
                  ? 'bg-[#FF2D2D] text-white shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>Most Popular</span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {MEMBERSHIP_PLANS.filter(
            (plan) => billingCycle === 'all' || plan.popular
          ).map((plan) => (
            <div
              key={plan.id}
              className={`relative p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 ${
                plan.popular
                  ? 'bg-zinc-900 border-2 border-[#FF2D2D] shadow-2xl'
                  : 'bg-zinc-900/80 border border-white/10 hover:border-white'
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#FF2D2D] text-black text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-black" />
                  <span>Most Popular Choice</span>
                </div>
              )}

              <div>
                {/* Plan Title & Tagline */}
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-black text-white uppercase tracking-tight">
                    {plan.name}
                  </h3>
                  <span className="text-[10px] font-black text-emerald-400 bg-emerald-950/80 px-2 py-0.5 border border-emerald-500/30 uppercase tracking-widest">
                    {plan.savings}
                  </span>
                </div>

                <p className="text-xs text-zinc-400 leading-relaxed font-sans mb-6">
                  {plan.tagline}
                </p>

                {/* Pricing Display */}
                <div className="mb-6 pb-6 border-b border-white/10">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl sm:text-4xl font-black text-white">
                      ₹{plan.price.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-zinc-400 font-bold uppercase tracking-wider">
                      / {plan.duration}
                    </span>
                  </div>
                  <div className="text-xs text-zinc-500 line-through mt-1 font-sans">
                    Original Price: ₹{plan.originalPrice.toLocaleString('en-IN')}
                  </div>
                </div>

                {/* Features List */}
                <div className="space-y-3 mb-8">
                  <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">
                    What's Included:
                  </p>
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-zinc-300 font-sans">
                      <div className="w-4 h-4 bg-[#FF2D2D]/20 flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-2.5 h-2.5 text-[#FF2D2D]" />
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div>
                <button
                  onClick={() => onSelectPlan(plan)}
                  className={`w-full py-4 font-black text-xs uppercase tracking-widest transition-colors flex items-center justify-center gap-2 group ${
                    plan.popular
                      ? 'bg-[#FF2D2D] text-white hover:bg-white hover:text-black'
                      : 'bg-zinc-800 text-white hover:bg-[#FF2D2D] hover:text-white border border-white/10'
                  }`}
                >
                  <span>Claim {plan.name}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <p className="text-[10px] text-center text-zinc-500 mt-3 flex items-center justify-center gap-1 font-sans uppercase tracking-wider">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  <span>Instant Activation at Gym Counter</span>
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Trial Banner */}
        <div className="mt-16 p-8 rounded-3xl bg-gradient-to-r from-[#1E1E1E] via-[#121212] to-[#1E1E1E] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-14 h-14 rounded-2xl bg-[#FF2D2D]/20 border border-[#FF2D2D]/40 flex items-center justify-center shrink-0 text-[#FF2D2D]">
              <Gift className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white uppercase tracking-tight">
                Not sure which plan to select?
              </h3>
              <p className="text-xs text-gray-400 mt-1 font-sans">
                Experience Bodyline Gym for free! Book a 1-day pass to test our machines and meet our coaches.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenFreeTrialModal}
            className="px-6 py-3.5 rounded-xl bg-white hover:bg-gray-200 text-black font-black text-xs uppercase tracking-wider shadow-lg shrink-0"
          >
            Get Free Trial Pass
          </button>
        </div>
      </div>
    </section>
  );
}
