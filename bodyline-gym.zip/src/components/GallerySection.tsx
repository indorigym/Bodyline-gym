import { useState } from 'react';
import { Maximize2, X, ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import { GALLERY_DATA } from '../data/gymData';
import { GalleryItem } from '../types';

export default function GallerySection() {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filterTabs = [
    { id: 'all', label: 'All Photos' },
    { id: 'workout', label: 'Workout Area' },
    { id: 'cardio', label: 'Cardio Zone' },
    { id: 'strength', label: 'Strength Section' },
    { id: 'group', label: 'Group Classes' },
    { id: 'equipment', label: 'Equipment' },
    { id: 'members', label: 'Members Training' },
  ];

  const filteredItems = GALLERY_DATA.filter((item) => {
    if (activeTab === 'all') return true;
    return item.category === activeTab;
  });

  const handleOpenLightbox = (item: GalleryItem) => {
    const idx = filteredItems.findIndex((g) => g.id === item.id);
    setLightboxIndex(idx !== -1 ? idx : 0);
  };

  const handleNextLightbox = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex((prev) => ((prev! + 1) % filteredItems.length));
    }
  };

  const handlePrevLightbox = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex((prev) => (prev! - 1 + filteredItems.length) % filteredItems.length);
    }
  };

  const activeLightboxItem = lightboxIndex !== null ? filteredItems[lightboxIndex] : null;

  return (
    <section id="gallery" className="py-20 bg-[#0E0E0E] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Visual Tour
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Bodyline Gym <span className="text-[#FF2D2D] text-stroke-white">Gallery</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            Take a look inside our state-of-the-art facility in Indore, showcasing our heavy strength zone, cardio floor, group studio, and motivating training environment.
          </p>

          {/* Filter Categories */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-xs font-black uppercase tracking-widest transition-all ${
                  activeTab === tab.id
                    ? 'bg-[#FF2D2D] text-white shadow-lg'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-white/5'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => handleOpenLightbox(item)}
              className="group relative h-64 bg-zinc-900 border border-white/10 border-l-2 border-l-[#FF2D2D] cursor-pointer shadow-lg hover:border-white transition-all duration-300 overflow-hidden"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 filter contrast-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80 group-hover:opacity-95 transition-opacity"></div>

              {/* Hover overlay icon */}
              <div className="absolute top-4 right-4 w-9 h-9 bg-black text-[#FF2D2D] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity border border-white/10">
                <Maximize2 className="w-4 h-4" />
              </div>

              {/* Caption Overlay */}
              <div className="absolute bottom-4 left-4 right-4">
                <span className="text-[9px] font-black uppercase tracking-widest text-black bg-[#FF2D2D] px-2 py-0.5">
                  {item.category}
                </span>
                <h3 className="text-sm font-black text-white uppercase tracking-tight mt-1 line-clamp-1">
                  {item.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeLightboxItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <button
            onClick={() => setLightboxIndex(null)}
            className="absolute top-6 right-6 p-3 rounded-full bg-[#1E1E1E] text-white hover:bg-[#FF2D2D] transition-colors z-20"
            aria-label="Close Lightbox"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Navigation Arrows */}
          <button
            onClick={handlePrevLightbox}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#1E1E1E]/80 text-white hover:bg-[#FF2D2D] transition-colors z-20"
            aria-label="Previous Image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={handleNextLightbox}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#1E1E1E]/80 text-white hover:bg-[#FF2D2D] transition-colors z-20"
            aria-label="Next Image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Content */}
          <div className="max-w-4xl w-full bg-[#121212] border border-[#1E1E1E] rounded-3xl overflow-hidden shadow-2xl">
            <div className="relative max-h-[70vh] flex items-center justify-center bg-black">
              <img
                src={activeLightboxItem.image}
                alt={activeLightboxItem.title}
                className="max-h-[70vh] w-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-6 bg-[#0B0B0B] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#FF2D2D]">
                  {activeLightboxItem.category} Zone
                </span>
                <h3 className="text-lg font-bold text-white uppercase">
                  {activeLightboxItem.title}
                </h3>
                <p className="text-xs text-gray-400 mt-1 font-sans">
                  {activeLightboxItem.caption}
                </p>
              </div>
              <div className="text-xs text-gray-500 shrink-0">
                {lightboxIndex! + 1} of {filteredItems.length}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
