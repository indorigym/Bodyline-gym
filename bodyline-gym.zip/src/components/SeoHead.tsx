import { useEffect } from 'react';
import { GYM_BUSINESS_INFO } from '../data/gymData';

interface SeoHeadProps {
  title?: string;
  description?: string;
}

export default function SeoHead({
  title = `${GYM_BUSINESS_INFO.name} | Best Gym in Indore | Premium Fitness Center`,
  description = `Train at ${GYM_BUSINESS_INFO.name}, Indore's top-rated 4.8★ fitness center at Itawaria Bazaar, Hukumchand Marg. Certified trainers, imported equipment, Zumba, CrossFit & affordable memberships. Book your free trial today!`,
}: SeoHeadProps) {
  useEffect(() => {
    // Document title
    document.title = title;

    // Meta Description
    let metaDesc = document.querySelector('meta[name="description"]');
    if (!metaDesc) {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      document.head.appendChild(metaDesc);
    }
    metaDesc.setAttribute('content', description);

    // Schema.org LocalBusiness JSON-LD injection
    const schemaData = {
      '@context': 'https://schema.org',
      '@type': 'ExerciseGym',
      name: GYM_BUSINESS_INFO.name,
      image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80',
      '@id': GYM_BUSINESS_INFO.googleMapsUrl,
      url: window.location.href,
      telephone: GYM_BUSINESS_INFO.phone,
      priceRange: '₹1500 - ₹11999',
      address: {
        '@type': 'PostalAddress',
        streetAddress: `${GYM_BUSINESS_INFO.address}, ${GYM_BUSINESS_INFO.landmark}`,
        addressLocality: GYM_BUSINESS_INFO.city,
        addressRegion: 'MP',
        postalCode: GYM_BUSINESS_INFO.pincode,
        addressCountry: 'IN',
      },
      geo: {
        '@type': 'GeoCoordinates',
        latitude: 22.7196,
        longitude: 75.8577,
      },
      openingHoursSpecification: [
        {
          '@type': 'OpeningHoursSpecification',
          dayOfWeek: [
            'Monday',
            'Tuesday',
            'Wednesday',
            'Thursday',
            'Friday',
            'Saturday',
            'Sunday',
          ],
          opens: '06:00',
          closes: '23:00',
        },
      ],
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: GYM_BUSINESS_INFO.googleRating,
        reviewCount: GYM_BUSINESS_INFO.reviewCount,
      },
    };

    let scriptTag = document.getElementById('json-ld-local-business');
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = 'json-ld-local-business';
      scriptTag.setAttribute('type', 'application/ld+json');
      document.head.appendChild(scriptTag);
    }
    scriptTag.textContent = JSON.stringify(schemaData);
  }, [title, description]);

  return null;
}
