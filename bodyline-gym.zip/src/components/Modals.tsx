import React, { useState, FormEvent } from 'react';
import { X, Calendar, Check, Sparkles, MessageSquare, Phone } from 'lucide-react';
import { MembershipPlan } from '../types';
import { GYM_BUSINESS_INFO } from '../data/gymData';
import BookingFormSection from './BookingFormSection';

interface ModalsProps {
  freeTrialModalOpen: boolean;
  onCloseFreeTrialModal: () => void;
  selectedPlanModal: MembershipPlan | null;
  onCloseSelectedPlanModal: () => void;
  prefilledGoal?: string;
}

export default function Modals({
  freeTrialModalOpen,
  onCloseFreeTrialModal,
  selectedPlanModal,
  onCloseSelectedPlanModal,
  prefilledGoal,
}: ModalsProps) {
  const [memberPhone, setMemberPhone] = useState('');
  const [memberName, setMemberName] = useState('');
  const [planClaimed, setPlanClaimed] = useState(false);

  const handleClaimPlanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberPhone || !memberName) return;
    setPlanClaimed(true);
  };

  return (
    <>
      {/* 1. Free Trial Booking Modal */}
      {freeTrialModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn overflow-y-auto">
          <div className="relative w-full max-w-4xl bg-black border border-white/20 overflow-hidden shadow-2xl my-8">
            <button
              onClick={onCloseFreeTrialModal}
              className="absolute top-4 right-4 p-2.5 bg-zinc-900 text-zinc-400 hover:text-white hover:bg-[#FF2D2D] transition-colors z-20"
              aria-label="Close Modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-2 sm:p-4">
              <BookingFormSection
                initialGoal={prefilledGoal || 'Weight Loss & Fat Burn'}
                onSuccess={() => {
                  // Keep modal open so user sees confirmation card
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* 2. Membership Claim Modal */}
      {selectedPlanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-lg bg-zinc-900 border border-[#FF2D2D] p-6 sm:p-8 text-white shadow-2xl">
            <button
              onClick={() => {
                setPlanClaimed(false);
                onCloseSelectedPlanModal();
              }}
              className="absolute top-4 right-4 p-2 bg-black text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {planClaimed ? (
              <div className="text-center py-6">
                <div className="w-14 h-14 bg-emerald-500 text-black font-black flex items-center justify-center mx-auto mb-3">
                  <Check className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-black uppercase text-white mb-2 tracking-tight">
                  {selectedPlanModal.name} Reserved!
                </h3>
                <p className="text-xs text-zinc-300 font-sans mb-6">
                  Great choice, <strong>{memberName}</strong>! We have reserved your{' '}
                  <strong>{selectedPlanModal.name} (₹{selectedPlanModal.price})</strong> pass. Visit our counter at Itawaria Bazaar or confirm via WhatsApp.
                </p>

                <div className="flex flex-col gap-2">
                  <a
                    href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=Hi%20Bodyline%20Gym%2C%20I%20want%20to%20activate%20the%20*${selectedPlanModal.name}*%20(₹${selectedPlanModal.price}).%20Name:%20${memberName}%2C%20Phone:%20${memberPhone}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Confirm via WhatsApp</span>
                  </a>

                  <button
                    onClick={() => {
                      setPlanClaimed(false);
                      onCloseSelectedPlanModal();
                    }}
                    className="w-full py-2.5 bg-black text-zinc-300 text-xs font-black uppercase tracking-wider border border-white/10"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-2.5 py-1 mb-2 tracking-[0.2em]">
                  Claim Membership Offer
                </div>

                <h3 className="text-2xl font-black uppercase text-white mb-1 tracking-tight">
                  {selectedPlanModal.name}
                </h3>

                <p className="text-xs text-zinc-400 mb-6 font-sans">
                  Special Rate: <strong className="text-white">₹{selectedPlanModal.price}</strong> for {selectedPlanModal.duration} ({selectedPlanModal.savings})
                </p>

                <form onSubmit={handleClaimPlanSubmit} className="space-y-4">
                  <div>
                    <label className="text-[11px] font-black uppercase tracking-wider text-zinc-300 block mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Vikram Jain"
                      value={memberName}
                      onChange={(e) => setMemberName(e.target.value)}
                      className="w-full bg-black border border-white/10 px-4 py-3 text-xs text-white focus:border-[#FF2D2D] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-black uppercase tracking-wider text-zinc-300 block mb-1">
                      Mobile Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 98260 12345"
                      value={memberPhone}
                      onChange={(e) => setMemberPhone(e.target.value)}
                      className="w-full bg-black border border-white/10 px-4 py-3 text-xs text-white focus:border-[#FF2D2D] focus:outline-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-4 bg-[#FF2D2D] hover:bg-white hover:text-black text-white font-black text-xs uppercase tracking-widest transition-colors"
                    >
                      Confirm {selectedPlanModal.name}
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
