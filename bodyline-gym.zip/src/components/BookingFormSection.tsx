import React, { useState, useEffect, FormEvent } from 'react';
import { Calendar, Phone, Mail, User, Target, Clock, MessageSquare, CheckCircle2, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { GYM_BUSINESS_INFO } from '../data/gymData';
import { BookingFormData } from '../types';

interface BookingFormSectionProps {
  initialGoal?: string;
  onSuccess?: () => void;
}

export default function BookingFormSection({
  initialGoal = 'Weight Loss & Fat Burn',
  onSuccess,
}: BookingFormSectionProps) {
  const [formData, setFormData] = useState<BookingFormData>({
    name: '',
    phone: '',
    email: '',
    fitnessGoal: initialGoal,
    preferredTime: 'Morning (6:00 AM - 9:00 AM)',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (initialGoal) {
      setFormData((prev) => ({ ...prev, fitnessGoal: initialGoal }));
    }
  }, [initialGoal]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.phone.trim()) {
      setErrorMsg('Please enter your full name and mobile number.');
      return;
    }

    if (formData.phone.length < 10) {
      setErrorMsg('Please enter a valid 10-digit phone number.');
      return;
    }

    setErrorMsg('');

    // Save to LocalStorage history
    try {
      const existing = JSON.parse(localStorage.getItem('bodyline_bookings') || '[]');
      existing.unshift({
        ...formData,
        timestamp: new Date().toISOString(),
      });
      localStorage.setItem('bodyline_bookings', JSON.stringify(existing));
    } catch (err) {
      console.warn('LocalStorage error:', err);
    }

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch (e) {
      // fallback if confetti canvas fails
    }

    setSubmitted(true);
    if (onSuccess) {
      onSuccess();
    }
  };

  // Generate WhatsApp link with form pre-fill
  const getWhatsAppBookingUrl = () => {
    const text = `Hi Bodyline Gym Indore! I want to book a 1-Day Free Trial.%0A%0A*Name:* ${
      formData.name || 'Friend'
    }%0A*Phone:* ${formData.phone || 'N/A'}%0A*Goal:* ${
      formData.fitnessGoal
    }%0A*Preferred Slot:* ${formData.preferredTime}`;
    return `https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=${text}`;
  };

  return (
    <section id="trial" className="py-20 bg-[#0E0E0E] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Form Info Banner */}
          <div className="lg:col-span-5">
            <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-4 tracking-[0.2em]">
              Complimentary Pass
            </div>

            <h2 className="text-3xl sm:text-5xl font-black text-white uppercase tracking-tighter mb-6">
              Book Your <span className="text-[#FF2D2D] text-stroke-white">1-Day Free Trial</span>
            </h2>

            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed mb-8 font-sans">
              Experience Indore's premium fitness atmosphere firsthand. Test our imported machinery, meet our certified trainers, and get a complimentary fitness evaluation.
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 text-xs text-zinc-300 font-sans">
                <div className="w-8 h-8 bg-[#FF2D2D] text-black flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span>100% Free - No credit card or obligation required</span>
              </div>

              <div className="flex items-center gap-3 text-xs text-zinc-300 font-sans">
                <div className="w-8 h-8 bg-[#FF2D2D] text-black flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span>Free 1-on-1 body composition checkup</span>
              </div>

              <div className="flex items-center gap-3 text-xs text-zinc-300 font-sans">
                <div className="w-8 h-8 bg-[#FF2D2D] text-black flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span>Full access to strength and cardio zones</span>
              </div>
            </div>

            <div className="p-4 bg-zinc-900 border border-white/10 border-l-4 border-l-[#FF2D2D] flex items-center justify-between">
              <div>
                <span className="text-[10px] text-zinc-400 font-black uppercase tracking-wider">Need Instant Booking?</span>
                <p className="text-xs text-white font-black tracking-wider">Call +91 96445 62525</p>
              </div>
              <a
                href={`tel:${GYM_BUSINESS_INFO.phone}`}
                className="px-4 py-2 bg-[#FF2D2D] text-white text-xs font-black uppercase tracking-widest hover:bg-white hover:text-black transition-colors"
              >
                Call Desk
              </a>
            </div>
          </div>

          {/* Right Column: Form Card */}
          <div className="lg:col-span-7">
            <div className="bg-zinc-900/90 border border-white/10 p-6 sm:p-10 shadow-2xl relative">
              {submitted ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-[#FF2D2D] text-black flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-black text-white uppercase mb-2 tracking-tight">
                    Free Trial Pass Reserved!
                  </h3>
                  <p className="text-xs text-zinc-300 mb-6 font-sans max-w-md mx-auto">
                    Thank you, <strong>{formData.name}</strong>! Our desk manager at Itawaria Bazaar, Indore will contact you at <strong>{formData.phone}</strong> to confirm your slot ({formData.preferredTime}).
                  </p>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={getWhatsAppBookingUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Confirm via WhatsApp</span>
                    </a>

                    <button
                      onClick={() => setSubmitted(false)}
                      className="w-full sm:w-auto px-6 py-3.5 bg-black border border-white/10 text-zinc-300 hover:text-white text-xs font-black uppercase tracking-widest"
                    >
                      Book Another Pass
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  {errorMsg && (
                    <div className="p-3 bg-red-950 border border-red-500 text-red-300 text-xs font-bold uppercase tracking-wider">
                      {errorMsg}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Name */}
                    <div>
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1.5 flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-[#FF2D2D]" />
                        <span>Full Name *</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Rahul Sharma"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData({ ...formData, name: e.target.value })
                        }
                        className="w-full bg-black border border-white/10 px-4 py-3 text-white text-xs focus:border-[#FF2D2D] focus:outline-none"
                      />
                    </div>

                    {/* Mobile Number */}
                    <div>
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1.5 flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5 text-[#FF2D2D]" />
                        <span>Mobile Number *</span>
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. 98260 00000"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        className="w-full bg-black border border-white/10 px-4 py-3 text-white text-xs focus:border-[#FF2D2D] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Email */}
                    <div>
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1.5 flex items-center gap-1">
                        <Mail className="w-3.5 h-3.5 text-[#FF2D2D]" />
                        <span>Email Address (Optional)</span>
                      </label>
                      <input
                        type="email"
                        placeholder="e.g. rahul@example.com"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        className="w-full bg-black border border-white/10 px-4 py-3 text-white text-xs focus:border-[#FF2D2D] focus:outline-none"
                      />
                    </div>

                    {/* Fitness Goal */}
                    <div>
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1.5 flex items-center gap-1">
                        <Target className="w-3.5 h-3.5 text-[#FF2D2D]" />
                        <span>Fitness Goal</span>
                      </label>
                      <select
                        value={formData.fitnessGoal}
                        onChange={(e) =>
                          setFormData({ ...formData, fitnessGoal: e.target.value })
                        }
                        className="w-full bg-black border border-white/10 px-4 py-3 text-white text-xs focus:border-[#FF2D2D] focus:outline-none"
                      >
                        <option value="Weight Loss & Fat Burn">Weight Loss & Fat Burn</option>
                        <option value="Muscle Building & Hypertrophy">Muscle Building & Hypertrophy</option>
                        <option value="Strength & Powerlifting">Strength & Powerlifting</option>
                        <option value="Zumba & Dance Cardio">Zumba & Dance Cardio</option>
                        <option value="CrossFit & Functional Fitness">CrossFit & Functional Fitness</option>
                        <option value="Personal Training (1-on-1)">Personal Training (1-on-1)</option>
                        <option value="General Health & Flexibility">General Health & Flexibility</option>
                      </select>
                    </div>
                  </div>

                  {/* Preferred Time Slot */}
                  <div>
                    <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1.5 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-[#FF2D2D]" />
                      <span>Preferred Time Slot</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        'Morning (6-9 AM)',
                        'Midday (11-3 PM)',
                        'Evening (5-9 PM)',
                        'Night (9-11 PM)',
                      ].map((slot) => (
                        <button
                          key={slot}
                          type="button"
                          onClick={() => setFormData({ ...formData, preferredTime: slot })}
                          className={`py-2.5 px-2 text-[11px] font-black uppercase tracking-wider text-center border transition-all ${
                            formData.preferredTime === slot
                              ? 'bg-[#FF2D2D] text-white border-[#FF2D2D]'
                              : 'bg-black text-zinc-400 border-white/10 hover:text-white'
                          }`}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-2 flex flex-col sm:flex-row gap-3">
                    <button
                      type="submit"
                      className="flex-1 py-4 bg-[#FF2D2D] hover:bg-white hover:text-black text-white font-black text-xs uppercase tracking-widest transition-colors flex items-center justify-center gap-2"
                    >
                      <Sparkles className="w-4 h-4 text-yellow-300" />
                      <span>Submit Free Trial Booking</span>
                    </button>

                    <a
                      href={getWhatsAppBookingUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-4 px-6 bg-emerald-950 border border-emerald-500 text-emerald-300 font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-emerald-900"
                    >
                      <MessageSquare className="w-4 h-4 text-emerald-400" />
                      <span>Book on WhatsApp</span>
                    </a>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
