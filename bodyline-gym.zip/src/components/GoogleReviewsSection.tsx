import { useState } from 'react';
import { Star, CheckCircle, ChevronLeft, ChevronRight, ExternalLink, MessageSquare } from 'lucide-react';
import { GOOGLE_REVIEWS_DATA, GYM_BUSINESS_INFO } from '../data/gymData';

export default function GoogleReviewsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextReview = () => {
    setCurrentIndex((prev) => (prev + 1) % GOOGLE_REVIEWS_DATA.length);
  };

  const prevReview = () => {
    setCurrentIndex(
      (prev) => (prev - 1 + GOOGLE_REVIEWS_DATA.length) % GOOGLE_REVIEWS_DATA.length
    );
  };

  return (
    <section id="reviews" className="py-20 bg-[#0E0E0E] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Top Google Rating Summary Banner */}
        <div className="p-8 bg-zinc-900 border border-white/10 shadow-2xl mb-12 flex flex-col md:flex-row items-center justify-between gap-6 border-l-4 border-l-[#FF2D2D]">
          <div className="flex items-center gap-5 text-center md:text-left">
            <div className="w-16 h-16 bg-[#FF2D2D] text-black font-black text-3xl flex items-center justify-center shrink-0">
              G
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <span className="text-3xl font-black text-white">4.8</span>
                <div className="flex items-center text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
              </div>
              <p className="text-xs text-zinc-300 font-bold uppercase tracking-wider mt-1 font-sans">
                Based on <strong>534+ Verified Google Reviews</strong> in Indore, MP
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href={GYM_BUSINESS_INFO.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3.5 bg-white hover:bg-[#FF2D2D] hover:text-white text-black text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-colors"
            >
              <span>View All 534+ Reviews</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Reviews Carousel */}
        <div className="max-w-4xl mx-auto relative">
          <div className="p-8 sm:p-12 bg-zinc-900/90 border border-white/10 relative overflow-hidden shadow-2xl">
            {/* Quote Watermark */}
            <div className="absolute top-4 right-8 text-8xl font-black text-white/5 pointer-events-none">
              “
            </div>

            <div className="relative z-10">
              {/* Star Row */}
              <div className="flex items-center gap-1 text-yellow-400 mb-4">
                {[...Array(GOOGLE_REVIEWS_DATA[currentIndex].rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
                <span className="text-xs text-zinc-400 ml-2 font-bold uppercase tracking-wider font-sans">
                  {GOOGLE_REVIEWS_DATA[currentIndex].relativeTimeText}
                </span>
              </div>

              {/* Review Text */}
              <p className="text-base sm:text-lg text-zinc-200 font-sans leading-relaxed italic mb-6">
                "{GOOGLE_REVIEWS_DATA[currentIndex].text}"
              </p>

              {/* Author Row */}
              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#FF2D2D] text-black font-black flex items-center justify-center text-sm">
                    {GOOGLE_REVIEWS_DATA[currentIndex].authorName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white flex items-center gap-1.5 uppercase tracking-wider">
                      <span>{GOOGLE_REVIEWS_DATA[currentIndex].authorName}</span>
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    </h4>
                    <p className="text-[11px] text-zinc-400 font-sans">Verified Google Local Guide</p>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={prevReview}
                    className="p-2.5 bg-zinc-800 text-white hover:bg-[#FF2D2D] transition-colors border border-white/10"
                    aria-label="Previous Review"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={nextReview}
                    className="p-2.5 bg-zinc-800 text-white hover:bg-[#FF2D2D] transition-colors border border-white/10"
                    aria-label="Next Review"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
