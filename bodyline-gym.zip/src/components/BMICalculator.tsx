import { useState } from 'react';
import { Calculator, Activity, ArrowRight, ShieldCheck, RefreshCw } from 'lucide-react';
import { BMICalculationResult } from '../types';

interface BMICalculatorProps {
  onOpenFreeTrialModalWithBmi?: (bmiResult: string) => void;
}

export default function BMICalculator({
  onOpenFreeTrialModalWithBmi,
}: BMICalculatorProps) {
  const [unitSystem, setUnitSystem] = useState<'metric' | 'imperial'>('metric');
  const [heightCm, setHeightCm] = useState<number>(172);
  const [weightKg, setWeightKg] = useState<number>(70);
  const [feet, setFeet] = useState<number>(5);
  const [inches, setInches] = useState<number>(8);
  const [pounds, setPounds] = useState<number>(154);
  const [age, setAge] = useState<number>(26);
  const [gender, setGender] = useState<'male' | 'female'>('male');

  // Compute BMI
  const calculateBMI = (): BMICalculationResult => {
    let heightInMeters = 0;
    let weightInKg = 0;

    if (unitSystem === 'metric') {
      heightInMeters = heightCm / 100;
      weightInKg = weightKg;
    } else {
      const totalInches = feet * 12 + inches;
      heightInMeters = totalInches * 0.0254;
      weightInKg = pounds * 0.453592;
    }

    if (heightInMeters <= 0 || weightInKg <= 0) {
      return {
        bmi: 0,
        category: 'Normal Weight',
        categoryColor: 'text-emerald-400',
        idealWeightRange: '60 - 72 kg',
        advice: 'Enter your metrics above to calculate.',
        recommendedServices: ['Weight Training', 'HIIT Classes'],
      };
    }

    const bmiVal = Number((weightInKg / (heightInMeters * heightInMeters)).toFixed(1));

    // Ideal weight for height (BMI 18.5 - 24.9)
    const minIdealKg = Math.round(18.5 * heightInMeters * heightInMeters);
    const maxIdealKg = Math.round(24.9 * heightInMeters * heightInMeters);
    const idealStr = `${minIdealKg} kg - ${maxIdealKg} kg`;

    if (bmiVal < 18.5) {
      return {
        bmi: bmiVal,
        category: 'Underweight',
        categoryColor: 'text-amber-400',
        idealWeightRange: idealStr,
        advice:
          'Focus on progressive hypertrophy weight training, caloric surplus with complex carbohydrates, and high protein intake to gain lean muscle mass.',
        recommendedServices: ['Weight Training', 'Personal Training', 'Nutrition Guidance'],
      };
    } else if (bmiVal >= 18.5 && bmiVal <= 24.9) {
      return {
        bmi: bmiVal,
        category: 'Normal Weight',
        categoryColor: 'text-emerald-400',
        idealWeightRange: idealStr,
        advice:
          'Excellent condition! Maintain your muscular tone, cardiovascular stamina, and core agility with balanced weight training and HIIT classes.',
        recommendedServices: ['CrossFit', 'HIIT Classes', 'Weight Training'],
      };
    } else if (bmiVal >= 25 && bmiVal <= 29.9) {
      return {
        bmi: bmiVal,
        category: 'Overweight',
        categoryColor: 'text-[#FF2D2D]',
        idealWeightRange: idealStr,
        advice:
          'Recommended caloric deficit diet, 3-4 days of heavy strength training combined with high-tempo Zumba, Kickboxing, or HIIT cardio to accelerate fat loss.',
        recommendedServices: ['HIIT Classes', 'Zumba', 'Kickboxing', 'Personal Training'],
      };
    } else {
      return {
        bmi: bmiVal,
        category: 'Obese',
        categoryColor: 'text-red-600',
        idealWeightRange: idealStr,
        advice:
          'Dedicated 1-on-1 personal training is strongly advised for safe joint preservation, structured fat burn, and macro-based meal management.',
        recommendedServices: ['Personal Training', 'Nutrition Guidance', 'Aerobics'],
      };
    }
  };

  const result = calculateBMI();

  return (
    <section id="bmi" className="py-20 bg-[#0B0B0B] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Fitness Calculator
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Interactive <span className="text-[#FF2D2D] text-stroke-white">BMI Calculator</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            Check your Body Mass Index (BMI) and receive customized fitness advice tailored for your physical parameters at Bodyline Gym.
          </p>
        </div>

        {/* Calculator Grid */}
        <div className="max-w-5xl mx-auto bg-zinc-900/90 border border-white/10 p-6 sm:p-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Controls */}
            <div className="lg:col-span-7">
              {/* Unit Toggle & Gender */}
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-6 border-b border-white/10">
                <div className="flex items-center gap-2 bg-black p-1 border border-white/10">
                  <button
                    onClick={() => setGender('male')}
                    className={`px-4 py-1.5 text-xs font-black uppercase tracking-widest transition-all ${
                      gender === 'male'
                        ? 'bg-[#FF2D2D] text-white shadow'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Male
                  </button>
                  <button
                    onClick={() => setGender('female')}
                    className={`px-4 py-1.5 text-xs font-black uppercase tracking-widest transition-all ${
                      gender === 'female'
                        ? 'bg-[#FF2D2D] text-white shadow'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Female
                  </button>
                </div>

                <div className="flex items-center gap-2 bg-black p-1 border border-white/10">
                  <button
                    onClick={() => setUnitSystem('metric')}
                    className={`px-3 py-1.5 text-xs font-black uppercase tracking-widest transition-all ${
                      unitSystem === 'metric'
                        ? 'bg-[#FF2D2D] text-white shadow'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Metric (cm/kg)
                  </button>
                  <button
                    onClick={() => setUnitSystem('imperial')}
                    className={`px-3 py-1.5 text-xs font-black uppercase tracking-widest transition-all ${
                      unitSystem === 'imperial'
                        ? 'bg-[#FF2D2D] text-white shadow'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Imperial (ft/lbs)
                  </button>
                </div>
              </div>

              {/* Sliders & Inputs */}
              <div className="space-y-6">
                {/* Height Input */}
                {unitSystem === 'metric' ? (
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300">
                        Height:
                      </label>
                      <span className="text-base font-black text-[#FF2D2D]">
                        {heightCm} cm
                      </span>
                    </div>
                    <input
                      type="range"
                      min="120"
                      max="220"
                      value={heightCm}
                      onChange={(e) => setHeightCm(Number(e.target.value))}
                      className="w-full h-2 bg-black rounded-none appearance-none cursor-pointer accent-[#FF2D2D]"
                    />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1">
                        Feet:
                      </label>
                      <input
                        type="number"
                        min="3"
                        max="8"
                        value={feet}
                        onChange={(e) => setFeet(Number(e.target.value))}
                        className="w-full bg-black border border-white/10 px-4 py-2.5 text-white font-bold text-sm focus:border-[#FF2D2D] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1">
                        Inches:
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="11"
                        value={inches}
                        onChange={(e) => setInches(Number(e.target.value))}
                        className="w-full bg-black border border-white/10 px-4 py-2.5 text-white font-bold text-sm focus:border-[#FF2D2D] focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                {/* Weight Input */}
                {unitSystem === 'metric' ? (
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-xs font-black uppercase tracking-wider text-zinc-300">
                        Weight:
                      </label>
                      <span className="text-base font-black text-[#FF2D2D]">
                        {weightKg} kg
                      </span>
                    </div>
                    <input
                      type="range"
                      min="35"
                      max="160"
                      value={weightKg}
                      onChange={(e) => setWeightKg(Number(e.target.value))}
                      className="w-full h-2 bg-black rounded-none appearance-none cursor-pointer accent-[#FF2D2D]"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="text-xs font-black uppercase tracking-wider text-zinc-300 block mb-1">
                      Weight (lbs):
                    </label>
                    <input
                      type="number"
                      min="80"
                      max="350"
                      value={pounds}
                      onChange={(e) => setPounds(Number(e.target.value))}
                      className="w-full bg-black border border-white/10 px-4 py-2.5 text-white font-bold text-sm focus:border-[#FF2D2D] focus:outline-none"
                    />
                  </div>
                )}

                {/* Age Input */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-black uppercase tracking-wider text-zinc-300">
                      Age:
                    </label>
                    <span className="text-base font-black text-white">{age} years</span>
                  </div>
                  <input
                    type="range"
                    min="14"
                    max="80"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="w-full h-2 bg-black rounded-none appearance-none cursor-pointer accent-[#FF2D2D]"
                  />
                </div>
              </div>
            </div>

            {/* Right Column: Dynamic Gauge & Advice Card */}
            <div className="lg:col-span-5 p-6 bg-black border border-white/10 flex flex-col justify-between text-center">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400">
                  Your BMI Result
                </span>

                <div className="my-4">
                  <span className="text-5xl font-black text-white tracking-tight">
                    {result.bmi}
                  </span>
                  <p className={`text-sm font-black uppercase tracking-wider mt-1 ${result.categoryColor}`}>
                    {result.category}
                  </p>
                </div>

                {/* Scale Meter Visual */}
                <div className="w-full bg-zinc-800 h-3 flex my-4 border border-white/5">
                  <div className="w-1/4 h-full bg-amber-400" title="Underweight (<18.5)"></div>
                  <div className="w-1/4 h-full bg-emerald-400" title="Normal (18.5-24.9)"></div>
                  <div className="w-1/4 h-full bg-orange-400" title="Overweight (25-29.9)"></div>
                  <div className="w-1/4 h-full bg-red-600" title="Obese (30+)"></div>
                </div>

                <div className="text-xs text-zinc-400 mb-4 font-sans">
                  Healthy Target Weight Range:{' '}
                  <strong className="text-white font-black">{result.idealWeightRange}</strong>
                </div>

                <div className="p-3.5 bg-zinc-900 border border-white/5 text-left text-xs text-zinc-300 font-sans leading-relaxed mb-6">
                  <strong className="text-[#FF2D2D] block uppercase font-black tracking-wider mb-1 text-[11px]">
                    Trainer Suggestion:
                  </strong>
                  {result.advice}
                </div>
              </div>

              <button
                onClick={() =>
                  onOpenFreeTrialModalWithBmi &&
                  onOpenFreeTrialModalWithBmi(
                    `BMI: ${result.bmi} (${result.category})`
                  )
                }
                className="w-full py-4 bg-[#FF2D2D] text-white font-black text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2"
              >
                <span>Get Free Custom Workout Plan</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
