import React, { useState, FormEvent } from 'react';
import { MapPin, Phone, MessageSquare, Clock, Mail, Send, CheckCircle2, Navigation, Instagram, Facebook } from 'lucide-react';
import { GYM_BUSINESS_INFO } from '../data/gymData';

export default function ContactSection() {
  const [formState, setFormState] = useState({
    name: '',
    phone: '',
    query: '',
  });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.phone) return;
    setSent(true);
  };

  return (
    <section id="contact" className="py-20 bg-[#0E0E0E] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Get In Touch
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Visit <span className="text-[#FF2D2D] text-stroke-white">Bodyline Gym</span> Indore
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            We are conveniently located at Holker Cloth Market, Itawaria Bazaar. Drop by during operating hours or connect with us directly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Contact Cards */}
          <div className="lg:col-span-5 space-y-4">
            {/* Address Box */}
            <div className="p-6 bg-zinc-900 border border-white/10 hover:border-white transition-colors border-l-4 border-l-[#FF2D2D]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#FF2D2D] text-black flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-1">
                    Gym Location
                  </h3>
                  <p className="text-sm font-bold text-white leading-snug font-sans">
                    {GYM_BUSINESS_INFO.fullAddress}
                  </p>
                  <a
                    href={GYM_BUSINESS_INFO.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-[#FF2D2D] font-black uppercase tracking-wider mt-2 hover:underline"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Get Directions on Google Maps</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Phone & WhatsApp Box */}
            <div className="p-6 bg-zinc-900 border border-white/10 hover:border-white transition-colors border-l-4 border-l-emerald-500">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-emerald-500 text-black flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-1">
                    Phone & WhatsApp
                  </h3>
                  <p className="text-lg font-black text-white tracking-wider">
                    {GYM_BUSINESS_INFO.phoneFormatted}
                  </p>
                  <div className="flex flex-wrap items-center gap-2 mt-3">
                    <a
                      href={`tel:${GYM_BUSINESS_INFO.phone}`}
                      className="px-4 py-2 bg-[#FF2D2D] text-white text-xs font-black uppercase tracking-widest flex items-center gap-1.5 hover:bg-white hover:text-black transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call Now</span>
                    </a>
                    <a
                      href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=Hi%20Bodyline%20Gym%2C%20I%20have%20an%20inquiry.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 bg-emerald-600 text-white text-xs font-black uppercase tracking-widest flex items-center gap-1.5 hover:bg-emerald-500 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Hours Box */}
            <div className="p-6 bg-zinc-900 border border-white/10 hover:border-white transition-colors border-l-4 border-l-amber-500">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-amber-500 text-black flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-1">
                    Working Hours
                  </h3>
                  <p className="text-sm font-black text-white uppercase tracking-wider">
                    {GYM_BUSINESS_INFO.openingHours}
                  </p>
                  <p className="text-xs text-zinc-400 mt-1 font-sans">
                    Open 7 Days a Week (Mon - Sun)
                  </p>
                </div>
              </div>
            </div>

            {/* Social Media Box */}
            <div className="p-6 bg-zinc-900 border border-white/10 hover:border-white transition-colors border-l-4 border-l-[#E1306C]">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-2">
                Follow Us On Social Media
              </h3>
              <p className="text-xs text-zinc-300 font-sans mb-4">
                Watch daily workout videos, member transformations, and gym updates on Instagram & Facebook.
              </p>
              <div className="flex flex-wrap gap-3">
                <a
                  href={GYM_BUSINESS_INFO.instagramUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  referrerPolicy="no-referrer"
                  className="px-4 py-2.5 bg-[#E1306C] text-white text-xs font-black uppercase tracking-wider flex items-center gap-2 hover:bg-white hover:text-black transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                  <span>Instagram Profile</span>
                </a>
                <a
                  href={GYM_BUSINESS_INFO.facebookUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  referrerPolicy="no-referrer"
                  className="px-4 py-2.5 bg-[#1877F2] text-white text-xs font-black uppercase tracking-wider flex items-center gap-2 hover:bg-white hover:text-black transition-colors"
                >
                  <Facebook className="w-4 h-4" />
                  <span>Facebook Page</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Google Maps & Message Box */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            {/* Google Map Card */}
            <div className="border border-white/10 overflow-hidden h-72 relative bg-zinc-900 shadow-xl">
              <iframe
                title="Bodyline Gym Indore Location Map"
                src={GYM_BUSINESS_INFO.mapEmbedUrl}
                className="w-full h-full border-0 filter grayscale contrast-125 invert-[0.9] opacity-90"
                loading="lazy"
                allowFullScreen
              ></iframe>

              <div className="absolute top-3 left-3 px-3 py-1.5 bg-black border border-white/10 text-white text-xs font-black uppercase tracking-widest flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#FF2D2D]" />
                <span>Itawaria Bazaar, Indore</span>
              </div>
            </div>

            {/* Quick Inquiry Form */}
            <div className="p-6 sm:p-8 bg-zinc-900 border border-white/10 shadow-2xl">
              <h3 className="text-lg font-black text-white uppercase mb-4 tracking-tight">
                Send Quick Inquiry
              </h3>

              {sent ? (
                <div className="p-4 bg-emerald-950 border border-emerald-500 text-emerald-300 text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>Message sent! Our desk team in Indore will call you back shortly.</span>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <input
                      type="text"
                      required
                      placeholder="Your Name"
                      value={formState.name}
                      onChange={(e) =>
                        setFormState({ ...formState, name: e.target.value })
                      }
                      className="bg-black border border-white/10 px-4 py-3 text-xs text-white placeholder-zinc-500 focus:border-[#FF2D2D] focus:outline-none"
                    />
                    <input
                      type="tel"
                      required
                      placeholder="Phone Number"
                      value={formState.phone}
                      onChange={(e) =>
                        setFormState({ ...formState, phone: e.target.value })
                      }
                      className="bg-black border border-white/10 px-4 py-3 text-xs text-white placeholder-zinc-500 focus:border-[#FF2D2D] focus:outline-none"
                    />
                  </div>
                  <textarea
                    rows={3}
                    placeholder="Your message / query about fees, timings, or personal training..."
                    value={formState.query}
                    onChange={(e) =>
                      setFormState({ ...formState, query: e.target.value })
                    }
                    className="w-full bg-black border border-white/10 px-4 py-3 text-xs text-white placeholder-zinc-500 focus:border-[#FF2D2D] focus:outline-none resize-none"
                  ></textarea>

                  <button
                    type="submit"
                    className="w-full py-4 bg-[#FF2D2D] hover:bg-white hover:text-black text-white font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Message</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
