import {
  Award,
  Dumbbell,
  Tag,
  Sparkles,
  Clock,
  FileText,
  Apple,
  Users,
} from 'lucide-react';
import { FEATURES_DATA } from '../data/gymData';

const iconMap: { [key: string]: any } = {
  Award,
  Dumbbell,
  Tag,
  Sparkles,
  Clock,
  FileText,
  Apple,
  Users,
};

export default function WhyChooseUs() {
  return (
    <section className="py-20 bg-[#0B0B0B] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            The Bodyline Difference
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Why Choose <span className="text-[#FF2D2D] text-stroke-white">Bodyline Gym</span> Indore?
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            We combine high-performance fitness gear, expert coaching, and a supportive community so you stay motivated every single day.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES_DATA.map((feature) => {
            const IconComp = iconMap[feature.iconName] || Dumbbell;
            return (
              <div
                key={feature.id}
                className="group relative bg-zinc-900/80 border border-white/10 border-l-2 border-l-[#FF2D2D] p-6 hover:border-white transition-all duration-300 shadow-xl"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-zinc-800 text-[#FF2D2D] group-hover:bg-[#FF2D2D] group-hover:text-white transition-colors flex items-center justify-center">
                    <IconComp className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-black text-[#FF2D2D] bg-[#FF2D2D]/10 px-2.5 py-1 uppercase tracking-widest">
                    {feature.tag}
                  </span>
                </div>

                <h3 className="text-lg font-black text-white uppercase tracking-tight mb-2 group-hover:text-[#FF2D2D] transition-colors">
                  {feature.title}
                </h3>

                <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
