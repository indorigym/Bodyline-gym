import { useState } from 'react';
import {
  Dumbbell,
  UserCheck,
  Zap,
  Flame,
  Music,
  Activity,
  ShieldAlert,
  Bike,
  HeartHandshake,
  Award,
  ChevronRight,
  Check,
  X,
  Calendar,
} from 'lucide-react';
import { SERVICES_DATA } from '../data/gymData';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onOpenFreeTrialModal: () => void;
}

const iconMap: { [key: string]: any } = {
  Dumbbell,
  UserCheck,
  Zap,
  Flame,
  Music,
  Activity,
  ShieldAlert,
  Bike,
  HeartHandshake,
  Award,
};

export default function ServicesSection({
  onOpenFreeTrialModal,
}: ServicesSectionProps) {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(
    null
  );
  const [filterCategory, setFilterCategory] = useState<string>('All');

  const categories = ['All', 'Strength', 'Cardio', 'Group Classes', 'Coaching'];

  const filteredServices = SERVICES_DATA.filter((service) => {
    if (filterCategory === 'All') return true;
    if (filterCategory === 'Strength')
      return (
        service.id === 'weight-training' ||
        service.id === 'crossfit' ||
        service.id === 'kickboxing'
      );
    if (filterCategory === 'Cardio')
      return (
        service.id === 'hiit-classes' ||
        service.id === 'cycling' ||
        service.id === 'aerobics'
      );
    if (filterCategory === 'Group Classes')
      return (
        service.id === 'zumba' ||
        service.id === 'dance-fitness' ||
        service.id === 'aerobics'
      );
    if (filterCategory === 'Coaching')
      return (
        service.id === 'personal-training' ||
        service.id === 'private-training'
      );
    return true;
  });

  return (
    <section id="services" className="py-20 bg-[#0E0E0E] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Our Offerings
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            World-Class <span className="text-[#FF2D2D] text-stroke-white">Fitness Services</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            From heavy Olympic lifting to high-energy Zumba and 1-on-1 personal coaching, Bodyline Gym offers comprehensive training programs tailored for all goals.
          </p>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-4 py-2 text-xs font-black uppercase tracking-widest transition-all ${
                  filterCategory === cat
                    ? 'bg-[#FF2D2D] text-white shadow-lg'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-white/5'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Animated Service Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredServices.map((service) => {
            const IconComp = iconMap[service.iconName] || Dumbbell;
            return (
              <div
                key={service.id}
                onClick={() => setSelectedService(service)}
                className="group relative bg-zinc-900/80 border border-white/10 border-l-2 border-l-[#FF2D2D] hover:border-white transition-all duration-300 p-6 flex flex-col justify-between cursor-pointer overflow-hidden shadow-xl"
              >
                <div>
                  {/* Top Row: Icon & Category */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-zinc-800 text-[#FF2D2D] group-hover:bg-[#FF2D2D] group-hover:text-white transition-all flex items-center justify-center">
                      <IconComp className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-[#FF2D2D] bg-[#FF2D2D]/10 px-2.5 py-1">
                      {service.category}
                    </span>
                  </div>

                  <h3 className="text-xl font-black text-white uppercase tracking-tight mb-2 group-hover:text-[#FF2D2D] transition-colors">
                    {service.title}
                  </h3>

                  <p className="text-zinc-400 text-xs leading-relaxed mb-4 line-clamp-3 font-sans">
                    {service.description}
                  </p>
                </div>

                {/* Benefits Tag List */}
                <div>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {service.benefits.slice(0, 2).map((b, i) => (
                      <span
                        key={i}
                        className="text-[10px] bg-black text-zinc-300 px-2 py-0.5 border border-white/5 flex items-center gap-1 font-sans"
                      >
                        <Check className="w-2.5 h-2.5 text-[#FF2D2D]" />
                        {b}
                      </span>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs font-black uppercase tracking-widest text-zinc-300 group-hover:text-[#FF2D2D]">
                    <span>Explore Program</span>
                    <ChevronRight className="w-4 h-4 text-[#FF2D2D] group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Service Detail Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-[#121212] border border-[#1E1E1E] rounded-2xl overflow-hidden shadow-2xl text-white">
            <button
              onClick={() => setSelectedService(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-[#0B0B0B]/80 text-gray-400 hover:text-white hover:bg-[#FF2D2D] transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative h-48 sm:h-56">
              <img
                src={selectedService.image}
                alt={selectedService.title}
                className="w-full h-full object-cover filter contrast-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/50 to-transparent"></div>
              <div className="absolute bottom-4 left-6">
                <span className="text-xs font-bold uppercase tracking-widest text-[#FF2D2D] bg-[#FF2D2D]/20 px-3 py-1 rounded-full border border-[#FF2D2D]/40">
                  {selectedService.category}
                </span>
                <h3 className="text-2xl sm:text-3xl font-black uppercase text-white mt-2">
                  {selectedService.title}
                </h3>
              </div>
            </div>

            <div className="p-6">
              <p className="text-gray-300 text-sm leading-relaxed mb-6 font-sans">
                {selectedService.longDescription}
              </p>

              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                Key Benefits & Outcomes:
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-8">
                {selectedService.benefits.map((b, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 p-2.5 rounded-lg bg-[#1E1E1E] border border-white/5 text-xs text-gray-200"
                  >
                    <Check className="w-4 h-4 text-[#FF2D2D] shrink-0" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={() => {
                    setSelectedService(null);
                    onOpenFreeTrialModal();
                  }}
                  className="flex-1 py-3 rounded-xl bg-[#FF2D2D] hover:bg-[#e02020] text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-[#FF2D2D]/30 flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Book Free Trial for {selectedService.title}</span>
                </button>
                <button
                  onClick={() => setSelectedService(null)}
                  className="px-6 py-3 rounded-xl bg-[#1E1E1E] hover:bg-[#282828] text-gray-300 text-xs font-bold uppercase"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
