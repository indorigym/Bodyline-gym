import { useState, useEffect } from 'react';
import {
  ArrowRight,
  Calendar,
  Phone,
  MessageSquare,
  Star,
  MapPin,
  ShieldCheck,
  Flame,
  Award,
  Users,
  Instagram,
  Facebook,
} from 'lucide-react';
import {
  GYM_BUSINESS_INFO,
  GYM_STATS,
  HERO_BG_IMAGE,
} from '../data/gymData';

interface HeroProps {
  onNavigate: (sectionId: string) => void;
  onOpenFreeTrialModal: () => void;
}

export default function Hero({ onNavigate, onOpenFreeTrialModal }: HeroProps) {
  // Animated counters logic
  const [counts, setCounts] = useState<{ [key: string]: number }>({
    members: 0,
    trainers: 0,
    years: 0,
    transformations: 0,
  });

  useEffect(() => {
    const duration = 2000;
    const steps = 50;
    const intervalTime = duration / steps;

    let currentStep = 0;
    const timer = setInterval(() => {
      currentStep++;
      const progress = Math.min(currentStep / steps, 1);

      setCounts({
        members: Math.floor(2500 * progress),
        trainers: Math.floor(12 * progress),
        years: Math.floor(10 * progress),
        transformations: Math.floor(1200 * progress),
      });

      if (currentStep >= steps) {
        clearInterval(timer);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, []);

  return (
    <section
      id="hero"
      className="relative min-h-screen pt-28 pb-16 md:pt-36 md:pb-24 flex items-center justify-center overflow-hidden bg-[#0B0B0B]"
    >
      {/* Background Image & Decorative Blurs */}
      <div className="absolute inset-0 z-0">
        <img
          src={HERO_BG_IMAGE}
          alt="Bodyline Gym Indore Equipment and Workout Zone"
          className="w-full h-full object-cover object-center opacity-20 filter contrast-125 scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B] via-[#0B0B0B]/80 to-[#0B0B0B]/90"></div>
        {/* Glow Spheres */}
        <div className="absolute top-20 left-20 w-96 h-96 bg-[#FF2D2D] rounded-full blur-[140px] opacity-25 pointer-events-none"></div>
        <div className="absolute bottom-10 right-20 w-80 h-80 bg-zinc-800 rounded-full blur-[120px] opacity-30 pointer-events-none"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Bold Impact Typography */}
          <div className="lg:col-span-7 text-center md:text-left">
            <div className="inline-block bg-[#FF2D2D] text-black text-[10px] sm:text-xs font-black uppercase px-3.5 py-1.5 mb-6 tracking-[0.2em]">
              Indore's #1 Premium Fitness Destination
            </div>

            <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black uppercase leading-[0.85] tracking-tighter text-white mb-6">
              Transform <br />
              Your <span className="text-transparent text-stroke-white border-b-2 border-[#FF2D2D] px-1">Life</span>
            </h1>

            <p className="text-zinc-400 text-base sm:text-lg max-w-xl mb-8 leading-relaxed font-sans">
              Train with imported Olympic equipment and expert master coaches at{' '}
              <strong className="text-white font-bold">Bodyline Gym, Itawaria Bazaar, Indore</strong>. Experience a luxury fitness environment engineered for real physical transformation.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mb-8">
              <button
                onClick={onOpenFreeTrialModal}
                className="bg-white text-black px-8 py-4 font-black uppercase text-xs sm:text-sm tracking-widest flex items-center gap-3 hover:bg-[#FF2D2D] hover:text-white transition-colors shadow-2xl group"
              >
                <span>Book Free Trial</span>
                <span className="text-lg group-hover:translate-x-1 transition-transform">→</span>
              </button>

              <button
                onClick={() => onNavigate('memberships')}
                className="bg-[#FF2D2D] text-white px-8 py-4 font-black uppercase text-xs sm:text-sm tracking-widest hover:bg-white hover:text-black transition-colors"
              >
                Membership Plans
              </button>

              <div className="flex items-center gap-3 bg-white/5 border border-white/10 px-5 py-3">
                <span className="text-zinc-400 text-xs font-bold uppercase tracking-widest">4.8 Rating</span>
                <span className="text-[#FF2D2D] text-sm">★★★★★</span>
              </div>
            </div>

            {/* Quick Contact Links */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
              <a
                href={GYM_BUSINESS_INFO.instagramUrl}
                target="_blank"
                rel="noreferrer noopener"
                referrerPolicy="no-referrer"
                className="px-4 py-2.5 bg-[#E1306C] text-white font-black text-xs uppercase tracking-wider flex items-center gap-2 hover:bg-white hover:text-black transition-colors"
              >
                <Instagram className="w-3.5 h-3.5" />
                <span>Instagram</span>
              </a>

              <a
                href={GYM_BUSINESS_INFO.facebookUrl}
                target="_blank"
                rel="noreferrer noopener"
                referrerPolicy="no-referrer"
                className="px-4 py-2.5 bg-[#1877F2] text-white font-black text-xs uppercase tracking-wider flex items-center gap-2 hover:bg-white hover:text-black transition-colors"
              >
                <Facebook className="w-3.5 h-3.5" />
                <span>Facebook</span>
              </a>

              <a
                href={`tel:${GYM_BUSINESS_INFO.phone}`}
                className="px-4 py-2.5 bg-zinc-900 border border-white/10 text-zinc-300 hover:text-white hover:border-[#FF2D2D] transition-colors text-xs font-bold uppercase tracking-wider flex items-center gap-2"
              >
                <Phone className="w-3.5 h-3.5 text-[#FF2D2D]" />
                <span>Call Desk</span>
              </a>

              <a
                href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=Hi%20Bodyline%20Gym%2C%20I%20want%20to%20inquire%20about%20free%20trial%20pass.`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2.5 bg-[#25D366] text-black font-black text-xs uppercase tracking-wider flex items-center gap-2 hover:bg-emerald-400 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 fill-black" />
                <span>WhatsApp</span>
              </a>

              <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-bold uppercase tracking-wider px-3 py-2">
                <MapPin className="w-3.5 h-3.5 text-[#FF2D2D]" />
                <span>Itawaria Bazaar</span>
              </div>
            </div>
          </div>

          {/* Right Column: Stats & Feature Cards */}
          <div className="lg:col-span-5 flex flex-col justify-center gap-6">
            {/* Stat Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5">
                <div className="text-3xl sm:text-4xl font-black text-[#FF2D2D]">
                  {counts.members || 2500}+
                </div>
                <div className="text-[10px] uppercase font-bold tracking-[0.2em] text-zinc-400 mt-1">
                  Active Members
                </div>
              </div>

              <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5">
                <div className="text-3xl sm:text-4xl font-black text-white">
                  {counts.trainers || 12}+
                </div>
                <div className="text-[10px] uppercase font-bold tracking-[0.2em] text-zinc-400 mt-1">
                  Master Trainers
                </div>
              </div>

              <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5">
                <div className="text-3xl sm:text-4xl font-black text-[#FF2D2D]">
                  {counts.years || 10}+ Yrs
                </div>
                <div className="text-[10px] uppercase font-bold tracking-[0.2em] text-zinc-400 mt-1">
                  Indore Excellence
                </div>
              </div>

              <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5">
                <div className="text-3xl sm:text-4xl font-black text-white">
                  {counts.transformations || 1200}+
                </div>
                <div className="text-[10px] uppercase font-bold tracking-[0.2em] text-zinc-400 mt-1">
                  Transformations
                </div>
              </div>
            </div>

            {/* Feature Cards with Left Accent Borders */}
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-4 p-4 bg-zinc-900/70 border-l-2 border-[#FF2D2D] hover:bg-zinc-900 transition-colors">
                <div className="w-12 h-12 flex-shrink-0 bg-zinc-800 flex items-center justify-center text-xl text-white">
                  <Users className="w-5 h-5 text-[#FF2D2D]" />
                </div>
                <div>
                  <h4 className="font-black uppercase text-sm tracking-tight text-white">
                    Pro Strength & Olympic Zone
                  </h4>
                  <p className="text-xs text-zinc-400 font-sans">
                    Imported Hammer Strength, Rogue bars & free weights setup.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-zinc-900/70 border-l-2 border-white/20 hover:border-[#FF2D2D] hover:bg-zinc-900 transition-colors">
                <div className="w-12 h-12 flex-shrink-0 bg-zinc-800 flex items-center justify-center text-xl text-white">
                  <Flame className="w-5 h-5 text-[#FF2D2D]" />
                </div>
                <div>
                  <h4 className="font-black uppercase text-sm tracking-tight text-white">
                    Zumba, HIIT & CrossFit Studio
                  </h4>
                  <p className="text-xs text-zinc-400 font-sans">
                    High-intensity group classes led by energetic certified instructors.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-zinc-900/70 border-l-2 border-white/20 hover:border-[#FF2D2D] hover:bg-zinc-900 transition-colors">
                <div className="w-12 h-12 flex-shrink-0 bg-zinc-800 flex items-center justify-center text-xl text-white">
                  <Award className="w-5 h-5 text-[#FF2D2D]" />
                </div>
                <div>
                  <h4 className="font-black uppercase text-sm tracking-tight text-white">
                    Custom Diet & Nutrition Plans
                  </h4>
                  <p className="text-xs text-zinc-400 font-sans">
                    Personalized Indian vegetarian & protein macro meal charts.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
