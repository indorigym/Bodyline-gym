import { Award, Instagram, Facebook, Calendar, MessageSquare } from 'lucide-react';
import { TRAINERS_DATA, GYM_BUSINESS_INFO } from '../data/gymData';
import { Trainer } from '../types';

interface TrainersSectionProps {
  onOpenFreeTrialModal: (trainerName?: string) => void;
}

export default function TrainersSection({
  onOpenFreeTrialModal,
}: TrainersSectionProps) {
  return (
    <section id="trainers" className="py-20 bg-[#0B0B0B] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Expert Guidance
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Meet Our <span className="text-[#FF2D2D] text-stroke-white">Certified Coaches</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            Our team of certified powerlifters, bodybuilding champions, and fitness specialists are committed to guiding every rep and perfecting your transformation.
          </p>
        </div>

        {/* Trainers Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {TRAINERS_DATA.map((trainer: Trainer) => (
            <div
              key={trainer.id}
              className="group relative bg-zinc-900/80 border border-white/10 border-l-2 border-l-[#FF2D2D] hover:border-white transition-all duration-300 overflow-hidden shadow-xl flex flex-col justify-between"
            >
              <div>
                {/* Photo Header */}
                <div className="relative h-72 sm:h-80 overflow-hidden bg-zinc-800">
                  <img
                    src={trainer.image}
                    alt={trainer.name}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500 filter contrast-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-transparent to-transparent"></div>

                  {/* Experience Badge */}
                  <div className="absolute top-4 left-4 px-3 py-1 bg-black text-[10px] font-black uppercase tracking-widest text-white flex items-center gap-1 border border-white/10">
                    <Award className="w-3 h-3 text-[#FF2D2D]" />
                    <span>{trainer.experience}</span>
                  </div>

                  {/* Social Icons - Always visible for touch & click */}
                  <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
                    <a
                      href={trainer.instagram}
                      target="_blank"
                      rel="noreferrer noopener"
                      referrerPolicy="no-referrer"
                      className="p-2 bg-black/90 text-white hover:bg-[#E1306C] transition-colors border border-white/20 shadow-lg"
                      aria-label={`${trainer.name} Instagram`}
                      title={`${trainer.name} on Instagram`}
                    >
                      <Instagram className="w-4 h-4" />
                    </a>
                    <a
                      href={trainer.facebook}
                      target="_blank"
                      rel="noreferrer noopener"
                      referrerPolicy="no-referrer"
                      className="p-2 bg-black/90 text-white hover:bg-[#1877F2] transition-colors border border-white/20 shadow-lg"
                      aria-label={`${trainer.name} Facebook`}
                      title={`${trainer.name} on Facebook`}
                    >
                      <Facebook className="w-4 h-4" />
                    </a>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-black text-white uppercase tracking-tight group-hover:text-[#FF2D2D] transition-colors">
                    {trainer.name}
                  </h3>
                  <p className="text-xs font-black text-[#FF2D2D] uppercase tracking-wider mb-3">
                    {trainer.role}
                  </p>

                  <p className="text-zinc-400 text-xs leading-relaxed mb-4 font-sans line-clamp-3">
                    {trainer.bio}
                  </p>

                  {/* Specializations Tags */}
                  <div className="space-y-1.5 mb-6">
                    <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500">
                      Specializations:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {trainer.specialization.map((spec, i) => (
                        <span
                          key={i}
                          className="text-[10px] bg-black text-zinc-300 px-2.5 py-0.5 border border-white/5 font-sans"
                        >
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Footer Action */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => onOpenFreeTrialModal(trainer.name)}
                  className="w-full py-3 bg-zinc-800 hover:bg-[#FF2D2D] text-white text-xs font-black uppercase tracking-widest transition-colors border border-white/10 flex items-center justify-center gap-2"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Book Session with {trainer.name.split(' ')[0]}</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* WhatsApp Direct Inquiry Banner */}
        <div className="mt-12 text-center">
          <p className="text-xs text-gray-400">
            Want 1-on-1 personal training packages or custom meal planning with our senior coaches?{' '}
            <a
              href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}?text=Hi%20Bodyline%20Gym%2C%20I%20am%20interested%20in%20Personal%20Training%20with%20your%20coaches.`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#FF2D2D] font-bold underline hover:text-white inline-flex items-center gap-1"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              Chat directly on WhatsApp
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
