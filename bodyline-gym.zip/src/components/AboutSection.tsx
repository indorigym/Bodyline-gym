import {
  Award,
  Sparkles,
  Clock,
  MapPin,
  CheckCircle2,
  Users,
  Dumbbell,
  ShieldCheck,
  Calendar,
} from 'lucide-react';
import { GYM_BUSINESS_INFO } from '../data/gymData';

interface AboutSectionProps {
  onNavigate: (sectionId: string) => void;
  onOpenFreeTrialModal: () => void;
}

export default function AboutSection({
  onNavigate,
  onOpenFreeTrialModal,
}: AboutSectionProps) {
  const highlights = [
    {
      title: 'Certified Master Trainers',
      desc: 'ACE, K11 & ISSA coaches with 9+ years experience guiding strength & fat loss.',
      icon: Award,
    },
    {
      title: 'Imported Equipment',
      desc: 'Heavy-duty power cages, Olympic benches, biomechanical cable machines & treadmills.',
      icon: Dumbbell,
    },
    {
      title: 'Clean & Sanitized',
      desc: 'Air-conditioned, daily disinfected floor, air purifiers, and hygienic locker rooms.',
      icon: Sparkles,
    },
    {
      title: 'Beginner & Women Friendly',
      desc: 'Safe, respectful, non-intimidating environment for members of all fitness levels.',
      icon: Users,
    },
    {
      title: 'Custom Workout Cards',
      desc: 'Individualized workout routines and macro-based Indian diet charts.',
      icon: ShieldCheck,
    },
    {
      title: 'Daily 6 AM - 11 PM Hours',
      desc: 'Open 7 days a week so you can train before or after business hours.',
      icon: Clock,
    },
  ];

  return (
    <section id="about" className="py-20 bg-[#0B0B0B] relative overflow-hidden border-t border-[#1E1E1E]">
      {/* Background Subtle Accents */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-[#FF2D2D]/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Image Collage & Badges */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden border border-[#1E1E1E] shadow-2xl bg-[#1E1E1E]">
              <img
                src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=800&q=80"
                alt="Bodyline Gym Indore Floor & Weights"
                className="w-full h-[450px] sm:h-[500px] object-cover filter contrast-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B] via-transparent to-transparent"></div>

              {/* Floating Badge 1: Location Badge */}
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-[#0B0B0B]/90 border border-white/10 backdrop-blur-md shadow-2xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FF2D2D]/20 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-[#FF2D2D]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    Prime Indore Location
                  </h4>
                  <p className="text-[11px] text-gray-300 line-clamp-1">
                    {GYM_BUSINESS_INFO.address}, Holker Cloth Market
                  </p>
                </div>
              </div>
            </div>

            {/* Floating Badge 2: Experience */}
            <div className="absolute -top-6 -right-4 sm:-right-6 p-4 rounded-2xl bg-gradient-to-br from-[#FF2D2D] to-[#b30000] text-white shadow-xl flex items-center gap-3">
              <span className="text-3xl font-black">10+</span>
              <div className="text-[10px] font-bold uppercase leading-tight">
                Years of
                <br />
                Excellence
              </div>
            </div>
          </div>

          {/* Right Column: About Content */}
          <div className="lg:col-span-7">
            <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-4 tracking-[0.2em]">
              About Bodyline Gym
            </div>

            <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter leading-none mb-6">
              Indore’s Premier <span className="text-[#FF2D2D] text-stroke-white">Fitness Destination</span>
            </h2>

            <p className="text-zinc-300 text-base sm:text-lg leading-relaxed mb-6 font-sans">
              Located in the heart of Indore at Itawaria Bazaar, Hukumchand Marg, <strong className="text-white">Bodyline Gym</strong> is built on a mission to bring world-class fitness infrastructure, certified personal coaching, and an empowering atmosphere to everyone.
            </p>

            <p className="text-zinc-400 text-sm leading-relaxed mb-8 font-sans">
              Whether your goal is rapid fat loss, building solid muscle mass, boosting stamina through Zumba and CrossFit, or staying healthy with personalized nutrition guidance, our team provides step-by-step motivation tailored to your lifestyle.
            </p>

            {/* Highlights Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 mb-8">
              {highlights.map((item, idx) => {
                const IconComponent = item.icon;
                return (
                  <div
                    key={idx}
                    className="p-4 bg-zinc-900/80 border-l-2 border-[#FF2D2D] hover:border-white transition-colors flex items-start gap-3"
                  >
                    <div className="p-2 bg-zinc-800 text-[#FF2D2D] shrink-0 mt-0.5">
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-black text-white uppercase tracking-wider">
                        {item.title}
                      </h3>
                      <p className="text-[11px] text-zinc-400 mt-0.5 leading-snug font-sans">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenFreeTrialModal}
                className="px-8 py-4 bg-[#FF2D2D] text-white font-black text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-colors flex items-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                <span>Book 1-Day Free Pass</span>
              </button>

              <button
                onClick={() => onNavigate('gallery')}
                className="px-8 py-4 bg-zinc-900 text-zinc-300 hover:text-white hover:border-[#FF2D2D] font-black text-xs uppercase tracking-widest border border-white/10 transition-colors flex items-center gap-2"
              >
                <span>View Gym Gallery</span>
                <CheckCircle2 className="w-4 h-4 text-[#FF2D2D]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
