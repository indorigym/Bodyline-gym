import { useState } from 'react';
import { Flame, Award, Quote, ArrowRight, CheckCircle2 } from 'lucide-react';
import { TRANSFORMATIONS_DATA } from '../data/gymData';
import { Transformation } from '../types';

interface TransformationsProps {
  onOpenFreeTrialModal: () => void;
}

export default function TransformationsSection({
  onOpenFreeTrialModal,
}: TransformationsProps) {
  const [activeTab, setActiveTab] = useState<number>(0);

  const activeStory: Transformation = TRANSFORMATIONS_DATA[activeTab];

  return (
    <section id="transformations" className="py-20 bg-[#0B0B0B] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Real Results
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Client <span className="text-[#FF2D2D] text-stroke-white">Transformations</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            Witness how ordinary members achieved extraordinary physical & mental breakthroughs with Bodyline Gym's structured workout and diet plans in Indore.
          </p>
        </div>

        {/* Member Selector Tabs */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {TRANSFORMATIONS_DATA.map((t, idx) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(idx)}
              className={`px-5 py-2.5 text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                activeTab === idx
                  ? 'bg-[#FF2D2D] text-white shadow-xl'
                  : 'bg-zinc-900 text-zinc-400 hover:text-white border border-white/5'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>{t.memberName}</span>
            </button>
          ))}
        </div>

        {/* Active Transformation Feature Card */}
        <div className="bg-zinc-900/90 border border-white/10 p-6 sm:p-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Before & After Photos */}
            <div className="lg:col-span-6 grid grid-cols-2 gap-4 relative">
              {/* Before Photo */}
              <div className="relative border border-white/10 bg-black">
                <img
                  src={activeStory.beforeImage}
                  alt={`${activeStory.memberName} Before`}
                  className="w-full h-64 sm:h-80 object-cover filter grayscale contrast-125"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 px-3 py-1 bg-black text-zinc-300 text-[10px] font-black uppercase tracking-widest border border-white/10">
                  Before
                </div>
              </div>

              {/* After Photo */}
              <div className="relative border-2 border-[#FF2D2D] bg-black shadow-xl">
                <img
                  src={activeStory.afterImage}
                  alt={`${activeStory.memberName} After`}
                  className="w-full h-64 sm:h-80 object-cover filter contrast-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 px-3 py-1 bg-[#FF2D2D] text-black text-[10px] font-black uppercase tracking-widest shadow-md">
                  After
                </div>
              </div>

              {/* Timeframe Tag Overlay */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-black border border-[#FF2D2D] text-white text-xs font-black uppercase tracking-widest shadow-2xl flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-[#FF2D2D]" />
                <span>Result in {activeStory.duration}</span>
              </div>
            </div>

            {/* Right Column: Member Story & Stats */}
            <div className="lg:col-span-6">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">
                  {activeStory.memberName}
                </h3>
                <span className="text-xs text-zinc-400 font-bold uppercase tracking-wider font-sans">
                  ({activeStory.age} yrs • {activeStory.occupation})
                </span>
              </div>

              <p className="text-xs font-black uppercase tracking-widest text-[#FF2D2D] mb-6">
                Goal: {activeStory.goal}
              </p>

              {/* Key Metrics Chips */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
                <div className="p-3 bg-black border border-white/10">
                  <span className="text-[10px] text-zinc-400 uppercase font-black tracking-widest">
                    Weight Change
                  </span>
                  <p className="text-base font-black text-white mt-0.5">
                    {activeStory.weightLost}
                  </p>
                </div>

                <div className="p-3 bg-black border border-white/10">
                  <span className="text-[10px] text-zinc-400 uppercase font-black tracking-widest">
                    Body Composition
                  </span>
                  <p className="text-base font-black text-white mt-0.5">
                    {activeStory.muscleGained}
                  </p>
                </div>

                <div className="p-3 bg-black border border-white/10 col-span-2 sm:col-span-1">
                  <span className="text-[10px] text-zinc-400 uppercase font-black tracking-widest">
                    Coached By
                  </span>
                  <p className="text-xs font-black text-[#FF2D2D] mt-1 flex items-center gap-1 uppercase tracking-wider">
                    <Award className="w-3.5 h-3.5" />
                    {activeStory.trainerName}
                  </p>
                </div>
              </div>

              {/* Testimonial Quote */}
              <div className="p-5 bg-black border border-white/10 relative mb-8">
                <Quote className="w-8 h-8 text-[#FF2D2D]/20 absolute top-3 right-4" />
                <p className="text-xs text-zinc-300 italic leading-relaxed font-sans relative z-10">
                  "{activeStory.testimonial}"
                </p>
              </div>

              {/* CTA */}
              <button
                onClick={onOpenFreeTrialModal}
                className="w-full sm:w-auto px-8 py-4 bg-[#FF2D2D] text-white font-black text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2"
              >
                <span>Start Your Transformation Journey</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
