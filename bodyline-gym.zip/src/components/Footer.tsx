import { useState } from 'react';
import { Dumbbell, Phone, MapPin, Clock, Star, Instagram, Facebook, MessageSquare, X, ShieldCheck } from 'lucide-react';
import { GYM_BUSINESS_INFO } from '../data/gymData';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenFreeTrialModal: () => void;
}

export default function Footer({ onNavigate, onOpenFreeTrialModal }: FooterProps) {
  const [activePolicyModal, setActivePolicyModal] = useState<'privacy' | 'terms' | null>(null);

  return (
    <footer className="bg-[#070707] text-gray-400 border-t border-[#1E1E1E] pt-16 pb-12 font-sans relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/5">
          {/* Col 1: Brand & Bio */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#FF2D2D] p-0.5 flex items-center justify-center">
                <Dumbbell className="w-6 h-6 text-black" />
              </div>
              <span className="text-2xl font-black text-white uppercase tracking-wider font-sans">
                BODYLINE<span className="text-[#FF2D2D]">GYM</span>
              </span>
            </div>

            <p className="text-xs text-zinc-400 leading-relaxed max-w-sm font-sans">
              Bodyline Gym is Indore's top-rated 4.8★ fitness center located at Itawaria Bazaar. We offer imported Olympic equipment, certified master coaches, Zumba, CrossFit, and structured transformation programs.
            </p>

            <div className="flex items-center gap-2 p-3 bg-zinc-900 border border-white/10 w-fit">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="text-xs font-black text-white uppercase tracking-wider">4.8 Rating on Google</span>
              <span className="text-xs text-zinc-500 font-sans">(534+ Reviews)</span>
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href={GYM_BUSINESS_INFO.instagramUrl}
                target="_blank"
                rel="noreferrer noopener"
                referrerPolicy="no-referrer"
                className="w-10 h-10 bg-zinc-900 text-white hover:bg-[#E1306C] transition-colors flex items-center justify-center border border-white/10 shadow-md"
                aria-label="Instagram"
                title="Follow Bodyline Gym on Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href={GYM_BUSINESS_INFO.facebookUrl}
                target="_blank"
                rel="noreferrer noopener"
                referrerPolicy="no-referrer"
                className="w-10 h-10 bg-zinc-900 text-white hover:bg-[#1877F2] transition-colors flex items-center justify-center border border-white/10 shadow-md"
                aria-label="Facebook"
                title="Follow Bodyline Gym on Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href={`https://wa.me/${GYM_BUSINESS_INFO.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-zinc-900 text-emerald-400 hover:bg-emerald-600 hover:text-white transition-colors flex items-center justify-center border border-white/10 shadow-md"
                aria-label="WhatsApp"
                title="Chat on WhatsApp"
              >
                <MessageSquare className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-widest text-white mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2.5 text-xs font-bold uppercase tracking-wider font-sans">
              {[
                { id: 'hero', label: 'Home' },
                { id: 'about', label: 'About Bodyline' },
                { id: 'services', label: 'Fitness Services' },
                { id: 'memberships', label: 'Membership Plans' },
                { id: 'trainers', label: 'Expert Coaches' },
                { id: 'gallery', label: 'Gym Gallery' },
                { id: 'transformations', label: 'Client Results' },
                { id: 'bmi', label: 'BMI Calculator' },
              ].map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => onNavigate(link.id)}
                    className="hover:text-[#FF2D2D] transition-colors text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Programs */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-widest text-white mb-4">
              Training Programs
            </h4>
            <ul className="space-y-2.5 text-xs font-bold uppercase tracking-wider font-sans text-zinc-400">
              <li>Weight & Strength Training</li>
              <li>1-on-1 Personal Coaching</li>
              <li>HIIT & Fat Loss Classes</li>
              <li>CrossFit & Calisthenics</li>
              <li>Zumba & Dance Cardio</li>
              <li>Aerobics & Flexibility</li>
              <li>Kickboxing & Combat</li>
              <li>Indoor Cycling / Spinning</li>
            </ul>
          </div>

          {/* Col 4: Contact Info */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-widest text-white mb-4">
              Gym Location
            </h4>
            <ul className="space-y-3 text-xs font-sans text-zinc-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#FF2D2D] shrink-0 mt-0.5" />
                <span>{GYM_BUSINESS_INFO.fullAddress}</span>
              </li>
              <li className="flex items-center gap-2.5 font-bold text-white">
                <Phone className="w-4 h-4 text-[#FF2D2D] shrink-0" />
                <a href={`tel:${GYM_BUSINESS_INFO.phone}`} className="hover:text-[#FF2D2D]">
                  {GYM_BUSINESS_INFO.phoneFormatted}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#FF2D2D] shrink-0" />
                <span>{GYM_BUSINESS_INFO.openingHours}</span>
              </li>
            </ul>

            <button
              onClick={onOpenFreeTrialModal}
              className="mt-4 w-full py-3 bg-[#FF2D2D] text-white text-xs font-black uppercase tracking-widest hover:bg-white hover:text-black transition-colors"
            >
              Book Free Trial Session
            </button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-gray-500">
          <p>© 2026 {GYM_BUSINESS_INFO.name}, Indore. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setActivePolicyModal('privacy')}
              className="hover:text-gray-300 transition-colors"
            >
              Privacy Policy
            </button>
            <span>•</span>
            <button
              onClick={() => setActivePolicyModal('terms')}
              className="hover:text-gray-300 transition-colors"
            >
              Terms & Conditions
            </button>
          </div>
        </div>
      </div>

      {/* Policy Modals */}
      {activePolicyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-xl bg-[#121212] border border-[#1E1E1E] rounded-3xl p-6 text-white max-h-[80vh] overflow-y-auto">
            <button
              onClick={() => setActivePolicyModal(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-[#1E1E1E] text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {activePolicyModal === 'privacy' ? (
              <div>
                <h3 className="text-xl font-bold uppercase mb-4 text-[#FF2D2D]">
                  Privacy Policy - Bodyline Gym Indore
                </h3>
                <div className="space-y-3 text-xs text-gray-300 font-sans leading-relaxed">
                  <p>
                    Bodyline Gym respects your personal privacy. Information collected during membership signup or trial bookings (such as name, mobile number, and email) is strictly used for internal gym desk communications and fitness plan tailoring.
                  </p>
                  <p>
                    We do not sell, rent, or distribute member contact information to third-party marketing entities.
                  </p>
                </div>
              </div>
            ) : (
              <div>
                <h3 className="text-xl font-bold uppercase mb-4 text-[#FF2D2D]">
                  Terms & Conditions - Bodyline Gym
                </h3>
                <div className="space-y-3 text-xs text-gray-300 font-sans leading-relaxed">
                  <p>
                    1. Members must adhere to gym floor etiquette, re-rack weights after use, and wipe down cardio equipment.
                  </p>
                  <p>
                    2. Memberships are non-transferable unless permitted in written contract by gym management.
                  </p>
                  <p>
                    3. Annual plan members may freeze membership for up to 30 days upon medical or travel notification.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </footer>
  );
}
