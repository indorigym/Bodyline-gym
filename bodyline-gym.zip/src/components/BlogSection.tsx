import { useState } from 'react';
import { BookOpen, Clock, User, ArrowRight, X } from 'lucide-react';
import { BLOG_POSTS } from '../data/gymData';
import { BlogPost } from '../types';

export default function BlogSection() {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  return (
    <section id="blog" className="py-20 bg-[#0B0B0B] relative border-t border-[#1E1E1E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-[#FF2D2D] text-black text-[10px] font-black uppercase px-3 py-1 mb-3 tracking-[0.2em]">
            Fitness Insights
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-4">
            Bodyline Fitness <span className="text-[#FF2D2D] text-stroke-white">Blog</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base font-sans">
            Expert workout protocols, Indian vegetarian nutrition guides, and fat loss tips written by our certified coaches in Indore.
          </p>
        </div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BLOG_POSTS.map((post) => (
            <div
              key={post.id}
              onClick={() => setSelectedPost(post)}
              className="group bg-zinc-900 border border-white/10 hover:border-white transition-all duration-300 cursor-pointer flex flex-col justify-between shadow-xl"
            >
              <div>
                <div className="relative h-48 bg-black overflow-hidden border-b border-white/10">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter contrast-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 px-3 py-1 bg-black text-[#FF2D2D] text-[10px] font-black uppercase tracking-widest border border-white/10">
                    {post.category}
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-3 text-[11px] text-zinc-400 mb-3 font-sans font-bold uppercase tracking-wider">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#FF2D2D]" />
                      {post.readTime}
                    </span>
                    <span>•</span>
                    <span>{post.date}</span>
                  </div>

                  <h3 className="text-lg font-black text-white uppercase tracking-tight mb-3 group-hover:text-[#FF2D2D] transition-colors leading-snug">
                    {post.title}
                  </h3>

                  <p className="text-xs text-zinc-400 leading-relaxed font-sans line-clamp-3 mb-4">
                    {post.summary}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 border-t border-white/5 flex items-center justify-between text-xs font-black uppercase tracking-wider text-[#FF2D2D] group-hover:text-white">
                <span className="flex items-center gap-1 text-zinc-400 font-sans">
                  <User className="w-3.5 h-3.5 text-[#FF2D2D]" />
                  {post.author}
                </span>
                <span className="flex items-center gap-1">
                  Read Article
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Blog Article Reader Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-[#121212] border border-[#1E1E1E] rounded-3xl overflow-hidden shadow-2xl text-white max-h-[85vh] flex flex-col">
            <button
              onClick={() => setSelectedPost(null)}
              className="absolute top-4 right-4 p-2.5 rounded-full bg-black/80 text-gray-400 hover:text-white hover:bg-[#FF2D2D] transition-colors z-20"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative h-48 sm:h-60 shrink-0">
              <img
                src={selectedPost.image}
                alt={selectedPost.title}
                className="w-full h-full object-cover filter contrast-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/50 to-transparent"></div>
              <div className="absolute bottom-4 left-6 right-6">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#FF2D2D] bg-[#FF2D2D]/20 px-2.5 py-1 rounded border border-[#FF2D2D]/30">
                  {selectedPost.category}
                </span>
                <h3 className="text-xl sm:text-2xl font-black uppercase text-white mt-2">
                  {selectedPost.title}
                </h3>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 font-sans text-xs sm:text-sm text-gray-300 leading-relaxed">
              <div className="flex items-center justify-between text-xs text-gray-400 pb-3 border-b border-white/10">
                <span>By {selectedPost.author}</span>
                <span>{selectedPost.date} ({selectedPost.readTime})</span>
              </div>

              <div className="whitespace-pre-line text-gray-200">
                {selectedPost.content}
              </div>

              <div className="pt-4 border-t border-white/10 flex flex-wrap gap-1.5">
                {selectedPost.tags.map((tag, i) => (
                  <span
                    key={i}
                    className="text-[10px] bg-[#1E1E1E] text-gray-400 px-2.5 py-1 rounded-full border border-white/5"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
