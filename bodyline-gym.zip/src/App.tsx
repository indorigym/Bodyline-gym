import { useState, useEffect } from 'react';
import SeoHead from './components/SeoHead';
import Header from './components/Header';
import Hero from './components/Hero';
import AboutSection from './components/AboutSection';
import ServicesSection from './components/ServicesSection';
import WhyChooseUs from './components/WhyChooseUs';
import MembershipPlans from './components/MembershipPlans';
import TrainersSection from './components/TrainersSection';
import GallerySection from './components/GallerySection';
import TransformationsSection from './components/TransformationsSection';
import GoogleReviewsSection from './components/GoogleReviewsSection';
import BMICalculator from './components/BMICalculator';
import BookingFormSection from './components/BookingFormSection';
import FaqSection from './components/FaqSection';
import ContactSection from './components/ContactSection';
import BlogSection from './components/BlogSection';
import Footer from './components/Footer';
import FloatingControls from './components/FloatingControls';
import Modals from './components/Modals';
import { MembershipPlan } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [freeTrialModalOpen, setFreeTrialModalOpen] = useState(false);
  const [selectedPlanModal, setSelectedPlanModal] = useState<MembershipPlan | null>(null);
  const [prefilledGoal, setPrefilledGoal] = useState<string>('');

  // Scroll listener to update active header navigation
  useEffect(() => {
    const handleScroll = () => {
      const sections = [
        'hero',
        'about',
        'services',
        'memberships',
        'trainers',
        'gallery',
        'transformations',
        'bmi',
        'reviews',
        'trial',
        'blog',
        'contact',
      ];

      const scrollPosition = window.scrollY + 200;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenFreeTrial = (goalOrTrainer?: string) => {
    if (goalOrTrainer) {
      setPrefilledGoal(goalOrTrainer);
    }
    setFreeTrialModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-white selection:bg-[#FF2D2D] selection:text-white font-sans antialiased overflow-x-hidden">
      {/* Dynamic SEO & LocalBusiness JSON-LD Metadata */}
      <SeoHead />

      {/* Navigation Bar */}
      <Header
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenFreeTrialModal={() => handleOpenFreeTrial()}
      />

      {/* Main Sections */}
      <main>
        {/* 1. Hero Section */}
        <Hero
          onNavigate={handleNavigate}
          onOpenFreeTrialModal={() => handleOpenFreeTrial()}
        />

        {/* 2. About Us */}
        <AboutSection
          onNavigate={handleNavigate}
          onOpenFreeTrialModal={() => handleOpenFreeTrial()}
        />

        {/* 3. Services */}
        <ServicesSection
          onOpenFreeTrialModal={() => handleOpenFreeTrial()}
        />

        {/* 4. Why Choose Us */}
        <WhyChooseUs />

        {/* 5. Membership Plans */}
        <MembershipPlans
          onSelectPlan={(plan) => setSelectedPlanModal(plan)}
          onOpenFreeTrialModal={() => handleOpenFreeTrial()}
        />

        {/* 6. Trainers */}
        <TrainersSection
          onOpenFreeTrialModal={(trainerName) =>
            handleOpenFreeTrial(trainerName ? `Personal Training with ${trainerName}` : undefined)
          }
        />

        {/* 7. Gym Gallery */}
        <GallerySection />

        {/* 8. Transformations */}
        <TransformationsSection
          onOpenFreeTrialModal={() => handleOpenFreeTrial('Physical Transformation Plan')}
        />

        {/* 9. Google Reviews */}
        <GoogleReviewsSection />

        {/* 10. BMI Calculator */}
        <BMICalculator
          onOpenFreeTrialModalWithBmi={(bmiSummary) =>
            handleOpenFreeTrial(`Custom Workout based on ${bmiSummary}`)
          }
        />

        {/* 11. Free Trial Booking Form Section */}
        <BookingFormSection
          initialGoal={prefilledGoal}
        />

        {/* 12. Blog Section */}
        <BlogSection />

        {/* 13. FAQ */}
        <FaqSection />

        {/* 14. Contact */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenFreeTrialModal={() => handleOpenFreeTrial()}
      />

      {/* Floating Controls */}
      <FloatingControls
        onOpenFreeTrialModal={() => handleOpenFreeTrial()}
      />

      {/* Global Modals */}
      <Modals
        freeTrialModalOpen={freeTrialModalOpen}
        onCloseFreeTrialModal={() => setFreeTrialModalOpen(false)}
        selectedPlanModal={selectedPlanModal}
        onCloseSelectedPlanModal={() => setSelectedPlanModal(null)}
        prefilledGoal={prefilledGoal}
      />
    </div>
  );
}
